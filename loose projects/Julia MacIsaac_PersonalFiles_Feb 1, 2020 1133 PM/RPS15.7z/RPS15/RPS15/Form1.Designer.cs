﻿namespace RPS15
{
    partial class RPS15Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.resultTxtBox = new System.Windows.Forms.TextBox();
            this.optionGrpBox = new System.Windows.Forms.GroupBox();
            this.rockRBtn = new System.Windows.Forms.RadioButton();
            this.lightningRBtn = new System.Windows.Forms.RadioButton();
            this.devilRBtn = new System.Windows.Forms.RadioButton();
            this.dragonRBtn = new System.Windows.Forms.RadioButton();
            this.waterRBtn = new System.Windows.Forms.RadioButton();
            this.airRBtn = new System.Windows.Forms.RadioButton();
            this.paperRBtn = new System.Windows.Forms.RadioButton();
            this.spongeRBtn = new System.Windows.Forms.RadioButton();
            this.wolfRBtn = new System.Windows.Forms.RadioButton();
            this.treeRBtn = new System.Windows.Forms.RadioButton();
            this.humanRBtn = new System.Windows.Forms.RadioButton();
            this.snakeRBtn = new System.Windows.Forms.RadioButton();
            this.scissorsRBtn = new System.Windows.Forms.RadioButton();
            this.fireRBtn = new System.Windows.Forms.RadioButton();
            this.gunRBtn = new System.Windows.Forms.RadioButton();
            this.playBtn = new System.Windows.Forms.Button();
            this.wheelPicBox = new System.Windows.Forms.PictureBox();
            this.comPicBox = new System.Windows.Forms.PictureBox();
            this.playerPicBox = new System.Windows.Forms.PictureBox();
            this.optionGrpBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wheelPicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comPicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPicBox)).BeginInit();
            this.SuspendLayout();
            // 
            // resultTxtBox
            // 
            this.resultTxtBox.Font = new System.Drawing.Font("Copperplate Gothic Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultTxtBox.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.resultTxtBox.Location = new System.Drawing.Point(12, 503);
            this.resultTxtBox.Multiline = true;
            this.resultTxtBox.Name = "resultTxtBox";
            this.resultTxtBox.ReadOnly = true;
            this.resultTxtBox.Size = new System.Drawing.Size(200, 115);
            this.resultTxtBox.TabIndex = 10;
            this.resultTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // optionGrpBox
            // 
            this.optionGrpBox.Controls.Add(this.rockRBtn);
            this.optionGrpBox.Controls.Add(this.lightningRBtn);
            this.optionGrpBox.Controls.Add(this.devilRBtn);
            this.optionGrpBox.Controls.Add(this.dragonRBtn);
            this.optionGrpBox.Controls.Add(this.waterRBtn);
            this.optionGrpBox.Controls.Add(this.airRBtn);
            this.optionGrpBox.Controls.Add(this.paperRBtn);
            this.optionGrpBox.Controls.Add(this.spongeRBtn);
            this.optionGrpBox.Controls.Add(this.wolfRBtn);
            this.optionGrpBox.Controls.Add(this.treeRBtn);
            this.optionGrpBox.Controls.Add(this.humanRBtn);
            this.optionGrpBox.Controls.Add(this.snakeRBtn);
            this.optionGrpBox.Controls.Add(this.scissorsRBtn);
            this.optionGrpBox.Controls.Add(this.fireRBtn);
            this.optionGrpBox.Controls.Add(this.gunRBtn);
            this.optionGrpBox.Location = new System.Drawing.Point(12, 12);
            this.optionGrpBox.Name = "optionGrpBox";
            this.optionGrpBox.Size = new System.Drawing.Size(200, 364);
            this.optionGrpBox.TabIndex = 9;
            this.optionGrpBox.TabStop = false;
            this.optionGrpBox.Text = "Choose a Hand";
            // 
            // rockRBtn
            // 
            this.rockRBtn.AutoSize = true;
            this.rockRBtn.Location = new System.Drawing.Point(6, 19);
            this.rockRBtn.Name = "rockRBtn";
            this.rockRBtn.Size = new System.Drawing.Size(51, 17);
            this.rockRBtn.TabIndex = 17;
            this.rockRBtn.TabStop = true;
            this.rockRBtn.Text = "Rock";
            this.rockRBtn.UseVisualStyleBackColor = true;
            this.rockRBtn.CheckedChanged += new System.EventHandler(this.rockRBtn_CheckedChanged);
            // 
            // lightningRBtn
            // 
            this.lightningRBtn.AutoSize = true;
            this.lightningRBtn.Location = new System.Drawing.Point(6, 318);
            this.lightningRBtn.Name = "lightningRBtn";
            this.lightningRBtn.Size = new System.Drawing.Size(68, 17);
            this.lightningRBtn.TabIndex = 16;
            this.lightningRBtn.TabStop = true;
            this.lightningRBtn.Text = "Lightning";
            this.lightningRBtn.UseVisualStyleBackColor = true;
            this.lightningRBtn.CheckedChanged += new System.EventHandler(this.lightningRBtn_CheckedChanged);
            // 
            // devilRBtn
            // 
            this.devilRBtn.AutoSize = true;
            this.devilRBtn.Location = new System.Drawing.Point(6, 295);
            this.devilRBtn.Name = "devilRBtn";
            this.devilRBtn.Size = new System.Drawing.Size(49, 17);
            this.devilRBtn.TabIndex = 15;
            this.devilRBtn.TabStop = true;
            this.devilRBtn.Text = "Devil";
            this.devilRBtn.UseVisualStyleBackColor = true;
            this.devilRBtn.CheckedChanged += new System.EventHandler(this.devilRBtn_CheckedChanged);
            // 
            // dragonRBtn
            // 
            this.dragonRBtn.AutoSize = true;
            this.dragonRBtn.Location = new System.Drawing.Point(6, 272);
            this.dragonRBtn.Name = "dragonRBtn";
            this.dragonRBtn.Size = new System.Drawing.Size(60, 17);
            this.dragonRBtn.TabIndex = 14;
            this.dragonRBtn.TabStop = true;
            this.dragonRBtn.Text = "Dragon";
            this.dragonRBtn.UseVisualStyleBackColor = true;
            this.dragonRBtn.CheckedChanged += new System.EventHandler(this.dragonRBtn_CheckedChanged);
            // 
            // waterRBtn
            // 
            this.waterRBtn.AutoSize = true;
            this.waterRBtn.Location = new System.Drawing.Point(6, 249);
            this.waterRBtn.Name = "waterRBtn";
            this.waterRBtn.Size = new System.Drawing.Size(54, 17);
            this.waterRBtn.TabIndex = 13;
            this.waterRBtn.TabStop = true;
            this.waterRBtn.Text = "Water";
            this.waterRBtn.UseVisualStyleBackColor = true;
            this.waterRBtn.CheckedChanged += new System.EventHandler(this.waterRBtn_CheckedChanged);
            // 
            // airRBtn
            // 
            this.airRBtn.AutoSize = true;
            this.airRBtn.Location = new System.Drawing.Point(6, 226);
            this.airRBtn.Name = "airRBtn";
            this.airRBtn.Size = new System.Drawing.Size(37, 17);
            this.airRBtn.TabIndex = 12;
            this.airRBtn.TabStop = true;
            this.airRBtn.Text = "Air";
            this.airRBtn.UseVisualStyleBackColor = true;
            this.airRBtn.CheckedChanged += new System.EventHandler(this.airRBtn_CheckedChanged);
            // 
            // paperRBtn
            // 
            this.paperRBtn.AutoSize = true;
            this.paperRBtn.Location = new System.Drawing.Point(6, 203);
            this.paperRBtn.Name = "paperRBtn";
            this.paperRBtn.Size = new System.Drawing.Size(53, 17);
            this.paperRBtn.TabIndex = 11;
            this.paperRBtn.TabStop = true;
            this.paperRBtn.Text = "Paper";
            this.paperRBtn.UseVisualStyleBackColor = true;
            this.paperRBtn.CheckedChanged += new System.EventHandler(this.paperRBtn_CheckedChanged);
            // 
            // spongeRBtn
            // 
            this.spongeRBtn.AutoSize = true;
            this.spongeRBtn.Location = new System.Drawing.Point(6, 180);
            this.spongeRBtn.Name = "spongeRBtn";
            this.spongeRBtn.Size = new System.Drawing.Size(62, 17);
            this.spongeRBtn.TabIndex = 10;
            this.spongeRBtn.TabStop = true;
            this.spongeRBtn.Text = "Sponge";
            this.spongeRBtn.UseVisualStyleBackColor = true;
            this.spongeRBtn.CheckedChanged += new System.EventHandler(this.spongeRBtn_CheckedChanged);
            // 
            // wolfRBtn
            // 
            this.wolfRBtn.AutoSize = true;
            this.wolfRBtn.Location = new System.Drawing.Point(6, 157);
            this.wolfRBtn.Name = "wolfRBtn";
            this.wolfRBtn.Size = new System.Drawing.Size(47, 17);
            this.wolfRBtn.TabIndex = 9;
            this.wolfRBtn.TabStop = true;
            this.wolfRBtn.Text = "Wolf";
            this.wolfRBtn.UseVisualStyleBackColor = true;
            this.wolfRBtn.CheckedChanged += new System.EventHandler(this.wolfRBtn_CheckedChanged);
            // 
            // treeRBtn
            // 
            this.treeRBtn.AutoSize = true;
            this.treeRBtn.Location = new System.Drawing.Point(6, 134);
            this.treeRBtn.Name = "treeRBtn";
            this.treeRBtn.Size = new System.Drawing.Size(47, 17);
            this.treeRBtn.TabIndex = 8;
            this.treeRBtn.TabStop = true;
            this.treeRBtn.Text = "Tree";
            this.treeRBtn.UseVisualStyleBackColor = true;
            this.treeRBtn.CheckedChanged += new System.EventHandler(this.treeRBtn_CheckedChanged);
            // 
            // humanRBtn
            // 
            this.humanRBtn.AutoSize = true;
            this.humanRBtn.Location = new System.Drawing.Point(6, 111);
            this.humanRBtn.Name = "humanRBtn";
            this.humanRBtn.Size = new System.Drawing.Size(59, 17);
            this.humanRBtn.TabIndex = 7;
            this.humanRBtn.TabStop = true;
            this.humanRBtn.Text = "Human";
            this.humanRBtn.UseVisualStyleBackColor = true;
            this.humanRBtn.CheckedChanged += new System.EventHandler(this.humanRBtn_CheckedChanged);
            // 
            // snakeRBtn
            // 
            this.snakeRBtn.AutoSize = true;
            this.snakeRBtn.Location = new System.Drawing.Point(6, 88);
            this.snakeRBtn.Name = "snakeRBtn";
            this.snakeRBtn.Size = new System.Drawing.Size(56, 17);
            this.snakeRBtn.TabIndex = 6;
            this.snakeRBtn.TabStop = true;
            this.snakeRBtn.Text = "Snake";
            this.snakeRBtn.UseVisualStyleBackColor = true;
            this.snakeRBtn.CheckedChanged += new System.EventHandler(this.snakeRBtn_CheckedChanged);
            // 
            // scissorsRBtn
            // 
            this.scissorsRBtn.AutoSize = true;
            this.scissorsRBtn.Location = new System.Drawing.Point(6, 65);
            this.scissorsRBtn.Name = "scissorsRBtn";
            this.scissorsRBtn.Size = new System.Drawing.Size(64, 17);
            this.scissorsRBtn.TabIndex = 5;
            this.scissorsRBtn.TabStop = true;
            this.scissorsRBtn.Text = "Scissors";
            this.scissorsRBtn.UseVisualStyleBackColor = true;
            this.scissorsRBtn.CheckedChanged += new System.EventHandler(this.scissorsRBtn_CheckedChanged);
            // 
            // fireRBtn
            // 
            this.fireRBtn.AutoSize = true;
            this.fireRBtn.Location = new System.Drawing.Point(6, 42);
            this.fireRBtn.Name = "fireRBtn";
            this.fireRBtn.Size = new System.Drawing.Size(42, 17);
            this.fireRBtn.TabIndex = 4;
            this.fireRBtn.TabStop = true;
            this.fireRBtn.Text = "Fire";
            this.fireRBtn.UseVisualStyleBackColor = true;
            this.fireRBtn.CheckedChanged += new System.EventHandler(this.fireRBtn_CheckedChanged);
            // 
            // gunRBtn
            // 
            this.gunRBtn.AutoSize = true;
            this.gunRBtn.Location = new System.Drawing.Point(6, 341);
            this.gunRBtn.Name = "gunRBtn";
            this.gunRBtn.Size = new System.Drawing.Size(45, 17);
            this.gunRBtn.TabIndex = 3;
            this.gunRBtn.TabStop = true;
            this.gunRBtn.Text = "Gun";
            this.gunRBtn.UseVisualStyleBackColor = true;
            this.gunRBtn.CheckedChanged += new System.EventHandler(this.gunRBtn_CheckedChanged);
            // 
            // playBtn
            // 
            this.playBtn.Font = new System.Drawing.Font("Copperplate Gothic Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playBtn.Location = new System.Drawing.Point(12, 382);
            this.playBtn.Name = "playBtn";
            this.playBtn.Size = new System.Drawing.Size(200, 115);
            this.playBtn.TabIndex = 8;
            this.playBtn.Text = "Play";
            this.playBtn.UseVisualStyleBackColor = true;
            this.playBtn.Click += new System.EventHandler(this.playBtn_Click);
            // 
            // wheelPicBox
            // 
            this.wheelPicBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.wheelPicBox.Image = global::RPS15.Properties.Resources.rsz_rps15;
            this.wheelPicBox.Location = new System.Drawing.Point(218, 218);
            this.wheelPicBox.Name = "wheelPicBox";
            this.wheelPicBox.Size = new System.Drawing.Size(404, 404);
            this.wheelPicBox.TabIndex = 11;
            this.wheelPicBox.TabStop = false;
            // 
            // comPicBox
            // 
            this.comPicBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.comPicBox.InitialImage = null;
            this.comPicBox.Location = new System.Drawing.Point(424, 12);
            this.comPicBox.Name = "comPicBox";
            this.comPicBox.Size = new System.Drawing.Size(200, 200);
            this.comPicBox.TabIndex = 7;
            this.comPicBox.TabStop = false;
            // 
            // playerPicBox
            // 
            this.playerPicBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.playerPicBox.InitialImage = null;
            this.playerPicBox.Location = new System.Drawing.Point(218, 12);
            this.playerPicBox.Name = "playerPicBox";
            this.playerPicBox.Size = new System.Drawing.Size(200, 200);
            this.playerPicBox.TabIndex = 6;
            this.playerPicBox.TabStop = false;
            // 
            // RPS15Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 629);
            this.Controls.Add(this.wheelPicBox);
            this.Controls.Add(this.resultTxtBox);
            this.Controls.Add(this.optionGrpBox);
            this.Controls.Add(this.playBtn);
            this.Controls.Add(this.comPicBox);
            this.Controls.Add(this.playerPicBox);
            this.Name = "RPS15Form";
            this.Text = "Rock Paper Scissors 15";
            this.Load += new System.EventHandler(this.RPS15Form_Load);
            this.optionGrpBox.ResumeLayout(false);
            this.optionGrpBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.wheelPicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comPicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playerPicBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox resultTxtBox;
        private System.Windows.Forms.GroupBox optionGrpBox;
        private System.Windows.Forms.RadioButton scissorsRBtn;
        private System.Windows.Forms.RadioButton fireRBtn;
        private System.Windows.Forms.RadioButton gunRBtn;
        private System.Windows.Forms.Button playBtn;
        private System.Windows.Forms.PictureBox comPicBox;
        private System.Windows.Forms.PictureBox playerPicBox;
        private System.Windows.Forms.PictureBox wheelPicBox;
        private System.Windows.Forms.RadioButton rockRBtn;
        private System.Windows.Forms.RadioButton lightningRBtn;
        private System.Windows.Forms.RadioButton devilRBtn;
        private System.Windows.Forms.RadioButton dragonRBtn;
        private System.Windows.Forms.RadioButton waterRBtn;
        private System.Windows.Forms.RadioButton airRBtn;
        private System.Windows.Forms.RadioButton paperRBtn;
        private System.Windows.Forms.RadioButton spongeRBtn;
        private System.Windows.Forms.RadioButton wolfRBtn;
        private System.Windows.Forms.RadioButton treeRBtn;
        private System.Windows.Forms.RadioButton humanRBtn;
        private System.Windows.Forms.RadioButton snakeRBtn;
    }
}


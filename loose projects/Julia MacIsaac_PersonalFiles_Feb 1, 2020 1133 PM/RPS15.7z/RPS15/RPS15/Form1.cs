﻿/*
 * Julian MacIsaac 
 * RPS 15
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace RPS15
{
    public partial class RPS15Form : Form
    {
        enum Hands { Rock, Fire, Scissors, Snake, Human, Tree, Wolf, Sponge, Paper, Air, Water, Dragon, Devil, Lightning, Gun }
        Hand playerChoice;
        public RPS15Form()
        {
            InitializeComponent();
        }

        public void RPS15Form_Load(object sender, EventArgs e)
        {
            playerChoice = null;
        }

        private void playBtn_Click(object sender, EventArgs e)
        {
            Hand comChoice = RandomHand();

            if (playerChoice != null) //checks to see if player has selected a hand
            {
                UpdateImage(playerPicBox, playerChoice); //redundant check to ensure player image is displayed correctly
                UpdateImage(comPicBox, comChoice); //updates image for com

                //logic to display game result
                if (playerChoice.getHandVal() == comChoice.getHandVal()) { resultTxtBox.Text = "Draw"; }
                else 
                {
                    //checks if value of player's hand is within the next 7 hands of the computer's hand
                    if ((comChoice.getHandVal() > playerChoice.getHandVal() && 
                        comChoice.getHandVal() < playerChoice.getHandVal() + 7) ||
                        comChoice.getHandVal() < playerChoice.getHandVal() - 7) { resultTxtBox.Text = "Win"; }
                    else { resultTxtBox.Text = "Lose"; }
                }
            }
            else { MessageBox.Show("Please select a hand"); }
        }

        private Hand RandomHand()
        {
            Random handGen = new Random();
            Hand genHand = convertIntToHand(handGen.Next(15));
            return genHand;
        }

        //used to select a Hand class based on its corresponding value
        private Hand convertIntToHand(int input)
        {
            switch (input)
            {
                case (int)Hands.Rock:
                    Hand Rock = new Hand((int)Hands.Rock, Properties.Resources.rock);
                    return Rock;
                case (int)Hands.Fire:
                    Hand Fire = new Hand((int)Hands.Fire, Properties.Resources.fire);
                    return Fire;
                case (int)Hands.Scissors:
                    Hand Scissors = new Hand((int)Hands.Scissors, Properties.Resources.scissors);
                    return Scissors;
                case (int)Hands.Snake:
                    Hand Snake = new Hand((int)Hands.Snake, Properties.Resources.snake);
                    return Snake;
                case (int)Hands.Human:
                    Hand Human = new Hand((int)Hands.Human, Properties.Resources.human);
                    return Human;
                case (int)Hands.Tree:
                    Hand Tree = new Hand((int)Hands.Tree, Properties.Resources.tree);
                    return Tree;
                case (int)Hands.Wolf:
                    Hand Wolf = new Hand((int)Hands.Wolf, Properties.Resources.wolf);
                    return Wolf;
                case (int)Hands.Sponge:
                    Hand Sponge = new Hand((int)Hands.Sponge, Properties.Resources.sponge);
                    return Sponge;
                case (int)Hands.Paper:
                    Hand Paper = new Hand((int)Hands.Paper, Properties.Resources.paper);
                    return Paper;
                case (int)Hands.Air:
                    Hand Air = new Hand((int)Hands.Air, Properties.Resources.air);
                    return Air;
                case (int)Hands.Water:
                    Hand Water = new Hand((int)Hands.Water, Properties.Resources.water);
                    return Water;
                case (int)Hands.Dragon:
                    Hand Dragon = new Hand((int)Hands.Dragon, Properties.Resources.dragon);
                    return Dragon;
                case (int)Hands.Devil:
                    Hand Devil = new Hand((int)Hands.Devil, Properties.Resources.devil);
                    return Devil;
                case (int)Hands.Lightning:
                    Hand Lightning = new Hand((int)Hands.Lightning, Properties.Resources.lightning);
                    return Lightning;
                case (int)Hands.Gun:
                    Hand Gun = new Hand((int)Hands.Gun, Properties.Resources.gun);
                    return Gun;
                default:
                    return null;
            }
        }

        private void UpdateImage(PictureBox picBox, Hand selectedHand)
        {
            //updates passed picturebox to the image contained in the passed Hand class
            if (selectedHand != null) { picBox.Image = selectedHand.getImage(); }
            else { MessageBox.Show("There was an error setting an image;"); }
            picBox.Refresh();
        }

        //each radio button click event updates the player's image and stores the player's hand
        private void rockRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Rock));
        }

        private void fireRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Fire));
        }

        private void scissorsRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Scissors));
        }

        private void snakeRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Snake));
        }

        private void humanRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Human));
        }

        private void treeRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Tree));
        }

        private void wolfRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Wolf));
        }

        private void spongeRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Sponge));
        }

        private void paperRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Paper));
        }

        private void airRBtn_CheckedChanged(object sender, EventArgs e) {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Air));
        }

        private void waterRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Water));
        }

        private void dragonRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Dragon));
        }

        private void devilRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Devil));
        }

        private void lightningRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Lightning));
        }

        private void gunRBtn_CheckedChanged(object sender, EventArgs e)
        {
            UpdateImage(playerPicBox, playerChoice = convertIntToHand((int)Hands.Gun));
        }
    }

    class Hand
    {
        private int handVal;
        private Image handImage;

        //constructors
        public Hand()
        {
            handVal = -1;
            handImage = null;
        }
        public Hand(int inputVal, Image inputImage)
        {
            handVal = inputVal;
            handImage = inputImage;
        }

        //getters
        public int getHandVal() 
        {
            return handVal;
        }
        public Image getImage()
        {
            return handImage;
        }
    }
}


package address.book;

/**
 * Julian MacIsaac
 * CPT-236
 */
public class AddressEntry {
    
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
        
    //constructor
    public AddressEntry() {
        initialize("","","","");
    }
    public AddressEntry(String aFirstName, String aLastName,
                        String anEmail, String aPhone) {
        initialize(aFirstName, aLastName, anEmail, aPhone);
    }
        
    //getters and setters
    public String getFirstName() {
        if (this.firstName == "") { System.out.println("No first name exists."); }
        return this.firstName;
    }
    public String getLastName() {
        if (this.lastName == "") { System.out.println("No last name exists."); }
        return this.lastName;
    }
    public String getEmail() {
        if (this.email == "") { System.out.println("No email exists."); }
        return this.email;
    }
    public String getPhone() {
        if (this.phone == "") { System.out.println("No phone number exists."); }
        return this.phone;    
    }
    
    public void setFirstName(String input) {
        if (validName(input)) { this.firstName = input; }
        else { System.out.println("Error setting first name."); }
    }
    public void setLastName(String input) {
        if (validName(input)) { this.lastName = input; }
        else { System.out.println("Error setting last name."); }
    }
    public void setEmail(String input) {
        if (validEmail(input)) { this.email = input; }
        else { System.out.println("Error setting email address."); }
    }
    public void setPhone(String input) {
        if (validPhone(input)) { this.phone = phone; }
        else { System.out.println("Error setting phone number."); }
    } 
        
    //other methods
    //validation
    //name validation - must be letters only
    private boolean validName(String aName) {
        for (int i = 0; i < aName.length(); i++) {
            if (Character.isDigit(aName.charAt(i)) == true)
                return false;
        }
        return true;
    }
    
    //email validation 
    /* format: aName@aWebsite.xxx
    * where aName and aWebsite are variable-length strings of 
    * letters and xxx is a three character domain 
    * aName allows numbers, the other strings do not*/
    private boolean validEmail(String anEmail) {
        int atSymbolIndex = anEmail.indexOf("@");
        int periodIndex = anEmail.indexOf(".");
        String aName, aWebsite, aDomain;
        boolean valid = true;
        
        if (atSymbolIndex != -1 && periodIndex != -1) {
            aName = anEmail.substring(0, atSymbolIndex);
            aWebsite = anEmail.substring(atSymbolIndex + 1, periodIndex);
            aDomain = anEmail.substring(periodIndex + 1);
            
            for (int i = 0; i < aName.length(); i++) {
                int current = aName.charAt(i);
                if (Character.isDigit(current) == false &&
                    Character.isLetter(current) == false)
                {
                    valid = false;
                }
            }
            if (validName(aWebsite) == false || 
                aDomain.length() != 3 || validName(aDomain) == false)
            {
                valid = false;
            }
        }
        else
            valid = false;
        
        return valid;
    }
    
    //phone number validation
    /* format: x-xxx-xxx-xxxx or x-xxx-xxx-xxxx exactly
    * where x is a digit */
    private boolean validPhone(String aPhone) {
        final char DELIM = '-';
        final int PHONE_SEGMENT_MAX = 4;
        final int PHONE_SEGMENT_LENGTH_REQUIREMENTS[] = {1, 3, 3, 4};
        
        String currentSegment;
        int currentIndex = 0, nextIndex = 0;
        boolean valid = true;
        
        for (int i = 0; i < PHONE_SEGMENT_MAX; i++) {
            nextIndex = aPhone.indexOf(currentIndex, DELIM);
            currentSegment = aPhone.substring(currentIndex, nextIndex);
            currentIndex = nextIndex;
            
            if (i == 0 && currentSegment.length() != 
                          PHONE_SEGMENT_LENGTH_REQUIREMENTS[i]) {
                i++;
            }
            
            if (nextIndex == -1 ||
                currentSegment.length() != PHONE_SEGMENT_LENGTH_REQUIREMENTS[i]) 
            {
                valid = false;
            }
        }
        
        return valid;
    }
    
    private void initialize(String aFirstName, String aLastName,
                            String anEmail, String aPhone) {
        setFirstName(aFirstName);
        setLastName(aLastName);
        setEmail(anEmail);
        setPhone(aPhone);
    }
    
    //static comparison method
    public static boolean compareAddressEntries(AddressEntry entry1,
                                                AddressEntry entry2) {
        if (entry1.getFirstName() == entry2.getLastName() &&
            entry1.getLastName() == entry2.getLastName() &&
            entry1.getEmail() == entry2.getEmail() &&
            entry1.getPhone() == entry2.getPhone()) 
        {
            return true;
        }
        else
            return false;
    }
}

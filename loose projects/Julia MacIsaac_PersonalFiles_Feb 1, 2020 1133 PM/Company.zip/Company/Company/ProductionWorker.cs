﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Company
{
    class ProductionWorker : Employee
    {
        int shftNum { get; set; }
        double payRate { get; set; }

        public ProductionWorker() : base()
        {
            shftNum = 0;
            payRate = 0.0;
        }
        public ProductionWorker(string name, string num, int shftNum, double payRate) : base(name, num)
        {
            this.shftNum = shftNum;
            this.payRate = payRate;
        }
    }
}

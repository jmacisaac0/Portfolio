﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Company
{
    class Employee
    {
        string name { get; set; }
        string num { get; set; }

        public Employee()
        {
            name = "";
            num = "";
        }
        public Employee(string name, string num)
        {
            this.name = name;
            this.num = num;
        }
    }
}

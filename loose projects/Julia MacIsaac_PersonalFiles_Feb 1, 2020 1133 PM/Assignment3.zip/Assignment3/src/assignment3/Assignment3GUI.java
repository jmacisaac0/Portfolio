
package assignment3;

import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

/**
 * 
 * @author Julian MacIsaac
 */
public class Assignment3GUI extends JFrame implements ActionListener {
    
    //Constants
    
    //private enum Specialty {Pediatrician, Obstetrician, General_Practitioner, 
    //                Primary_Care, Gynecologist}
    private static final String SPECIALTY_LIST[] = {"Pediatrician", "Obstetrician", 
                          "General Practitioner", "Primary Care", 
                          "Gynecologist"};
    private static final int PATIENT_ID_LENGTH = 8;
    
    //GUI Dimensions
    private static final int GUI_ELEMENT_LENGTH_BASE = 10;
    private static final int GUI_ELEMENT_HORIZONTAL_PADDING = 20;
    private static final int GUI_ELEMENT_GROUP_SPACING = 10;
    private static final int GUI_ELEMENT_OUTPUT_AREA_ROW_NUMBER = 5;
    private static final int GUI_ELEMENT_TAB_SIZE = 4;
        
    //Member Variables
    
    private LinkedList<String> exceptionLog;
    private ArrayList<ArrayList<Billing>> billingList;
    private int totalStoredBillings;
    
    //GUI Objects
    Container contentPane;
    JPanel IOPnl, billingPnl, patientPnl, doctorPnl, buttonPnl; 
    JLabel patientNameLbl, patientIDLbl, doctorNameLbl, doctorSpecialtyLbl, 
            doctorFeeLbl;
    JTextField patientNameTxt, patientIDTxt, doctorNameTxt, doctorFeeTxt;
    JComboBox doctorSpecialtyComboBox;
    JButton clearPatientBtn, clearDoctorBtn, clearAllInputBtn, newBillBtn, 
            exitBtn, printTotalBtn, clearBillingsBtn;
    JTextArea outputArea, billListingArea;
    
    //Constructors
    
    /**
     * Base GUI constructor.
     */
    public Assignment3GUI() {  

        exceptionLog = new LinkedList<>();
        billingList = new ArrayList<>();
        totalStoredBillings = 0;
    }
    
    //Additional Methods
    
    /**
     * Generates GUI. Must be run after class declaration and initialization.
     */
    public void generateGUI() {
        
        //GUI Setup
        this.setTitle("Patient Billing Calculator");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        contentPane = this.getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.LINE_AXIS));
                
        patientPnl = new JPanel();
        patientPnl.setLayout(
                new GridLayout(2, 2, GUI_ELEMENT_HORIZONTAL_PADDING, 0));
        patientNameLbl = new JLabel("Enter patient name:");
        patientIDLbl = new JLabel("Enter 8-digit patient ID number:");
        patientNameTxt = new JTextField(GUI_ELEMENT_LENGTH_BASE);
        patientIDTxt = new JTextField(GUI_ELEMENT_LENGTH_BASE);
        patientPnl.add(patientNameLbl);
        patientPnl.add(patientNameTxt);
        patientPnl.add(patientIDLbl);
        patientPnl.add(patientIDTxt);
        
        doctorPnl = new JPanel();
        doctorPnl.setLayout(
                new GridLayout(3, 2, GUI_ELEMENT_HORIZONTAL_PADDING, 0));
        doctorNameLbl = new JLabel("Enter doctor name:");
        doctorSpecialtyLbl = new JLabel("Select doctor specialty:");
        doctorFeeLbl = new JLabel("Enter doctor appointment fee:");
        doctorNameTxt = new JTextField(GUI_ELEMENT_LENGTH_BASE);
        doctorFeeTxt = new JTextField(GUI_ELEMENT_LENGTH_BASE);
        doctorSpecialtyComboBox = new JComboBox(SPECIALTY_LIST);
        doctorPnl.add(doctorNameLbl);
        doctorPnl.add(doctorNameTxt);
        doctorPnl.add(doctorSpecialtyLbl);
        doctorPnl.add(doctorSpecialtyComboBox);
        doctorPnl.add(doctorFeeLbl);
        doctorPnl.add(doctorFeeTxt);
        
        buttonPnl = new JPanel();
        buttonPnl.setLayout(new GridLayout(2, 2));
        newBillBtn = new JButton("New Billing");
        newBillBtn.addActionListener(this);
        printTotalBtn = new JButton("Print Total");
        printTotalBtn.addActionListener(this);
        clearAllInputBtn = new JButton("Clear All");
        clearAllInputBtn.addActionListener(this);
        exitBtn = new JButton("Exit Program");
        exitBtn.addActionListener(this);
        buttonPnl.add(newBillBtn);
        buttonPnl.add(printTotalBtn);
        buttonPnl.add(clearAllInputBtn);
        buttonPnl.add(exitBtn);
        
        Dimension verticalDivider = new Dimension(0, GUI_ELEMENT_GROUP_SPACING);
        Border padding = BorderFactory.createEmptyBorder(
                GUI_ELEMENT_GROUP_SPACING, GUI_ELEMENT_GROUP_SPACING,
                GUI_ELEMENT_GROUP_SPACING, GUI_ELEMENT_GROUP_SPACING);

        IOPnl = new JPanel();
        IOPnl.setLayout(new BoxLayout(IOPnl, BoxLayout.PAGE_AXIS));
        IOPnl.setAlignmentX(LEFT_ALIGNMENT);
        IOPnl.setBorder(padding);  
        IOPnl.add(patientPnl);
        IOPnl.add(Box.createRigidArea(verticalDivider));    
        clearPatientBtn = new JButton("Clear Patient Information");
        clearPatientBtn.addActionListener(this);
        clearPatientBtn.setAlignmentX(RIGHT_ALIGNMENT);
        IOPnl.add(clearPatientBtn);
        IOPnl.add(Box.createRigidArea(verticalDivider));    
        IOPnl.add(doctorPnl);
        IOPnl.add(Box.createRigidArea(verticalDivider));    
        clearDoctorBtn = new JButton("Clear Doctor Information");
        clearDoctorBtn.addActionListener(this);
        clearDoctorBtn.setAlignmentX(RIGHT_ALIGNMENT);
        IOPnl.add(clearDoctorBtn);
        IOPnl.add(Box.createRigidArea(verticalDivider));    
        IOPnl.add(buttonPnl);
        IOPnl.add(Box.createRigidArea(verticalDivider));
        outputArea = new JTextArea(GUI_ELEMENT_OUTPUT_AREA_ROW_NUMBER, 1);
        outputArea.setEditable(false);
        IOPnl.add(outputArea);
        
        billingPnl = new JPanel();
        billingPnl.setLayout(new BoxLayout(billingPnl, BoxLayout.PAGE_AXIS));
        billListingArea = new JTextArea();
        billListingArea.setEditable(false);
        billListingArea.setTabSize(GUI_ELEMENT_TAB_SIZE);
        billListingArea.setMinimumSize(
                new Dimension(0, (GUI_ELEMENT_LENGTH_BASE * 3)));
        billingPnl.add(billListingArea);
        clearBillingsBtn = new JButton("Clear Billings");
        clearBillingsBtn.addActionListener(this);
        billingPnl.add(clearBillingsBtn);
        
        contentPane.add(IOPnl);
        contentPane.add(billingPnl);
        this.pack();
        this.setVisible(true);
    }
    
    /**
     * 
     * @param e 
     */   
    @Override
    public void actionPerformed(ActionEvent e) {
        
        outputArea.setText("");
        
        String actionCommand = e.getActionCommand();
        
        switch (actionCommand) {
            case "Clear Patient Information":
                patientNameTxt.setText("");
                patientIDTxt.setText("");
                break;
                        
            case "Clear Doctor Information":
                doctorNameTxt.setText("");
                doctorFeeTxt.setText("");
                doctorSpecialtyComboBox.setSelectedIndex(0);
                break;
                
            case "Clear All":
                patientNameTxt.setText("");
                patientIDTxt.setText("");
                doctorNameTxt.setText("");
                doctorFeeTxt.setText("");
                doctorSpecialtyComboBox.setSelectedIndex(0);
                break;
                
            case "Clear Billing":
                billListingArea.setText("");
                billingList.clear();
                break;
                
            case "New Billing":
                if (!(patientNameTxt.getText().equals("") || 
                        patientIDTxt.getText().equals("") || 
                        doctorNameTxt.getText().equals("") || 
                        doctorFeeTxt.getText().equals(""))) {
                    Patient p = new Patient(patientNameTxt.getText(),
                            patientIDTxt.getText());
                    Doctor d = new Doctor(doctorNameTxt.getText(),
                            doctorSpecialtyComboBox.getSelectedIndex(),
                            Double.parseDouble(doctorFeeTxt.getText()));
                    Billing tempBilling = new Billing(d, p);
                    
                    this.addNewBilling(tempBilling);
                }
                else
                    exceptionLog.add("Please make sure all fields are filled.");
                this.printExceptionLog();
                break;
                
            case "Print Total":
                double total = 0;
                for (int i = 0; i < billingList.size(); i++) {
                    
                    double patientTotal = 0;
                    ArrayList<Billing> tempArrayList = billingList.get(i);
                    String patientName = 
                            tempArrayList.get(0).getPatient().getName();
                    for (int j = 0; j < tempArrayList.size(); j++) {
                        
                        Billing tempBilling = tempArrayList.get(j);
                        int timesVisited = tempBilling.getTimesVisited();
                        double doctorFee = 
                                tempBilling.getDoctor().getOfficeVisitFee();
                        patientTotal = (doctorFee * timesVisited);
                    }
                    total += patientTotal;
                    outputArea.append();
                }
                
            case "Exit Program":
                System.exit(0);
                break;
                
            default:
                System.out.println("ERROR: actionPerformed()");
                break;
        }
        this.pack(); 
    }
    
    //Additional Methods
    /**
     * Prints and clears exception log to output area.
     */
    private void printExceptionLog() {
        
        for (Iterator i = exceptionLog.iterator(); i.hasNext();) {
            outputArea.append(i.next() + "\n");
        }
        exceptionLog.clear();
        
    }
    /**
     * Adds new billing to billingList.
     * @param b A billing to add.
     */
    private void addNewBilling(Billing b) {
        
        if (totalStoredBillings == 0) {
            ArrayList<Billing> tempArrayList = new ArrayList<>();
            tempArrayList.add(b);
            this.billingList.add(tempArrayList);
        }
        else {
            Billing duplicateBilling = null;
            boolean patientFound = false;
            for (int i = 0; i < billingList.size() && duplicateBilling == null; 
                    i++) {
                
                ArrayList<Billing> tempArrayList = billingList.get(i);
                Billing firstBilling = tempArrayList.get(0);
                
                if (firstBilling.equals(b)) {
                    
                    duplicateBilling = firstBilling;
                }
                else if (firstBilling.getPatient().equals(b.getPatient())) {
                    
                    patientFound = true;
                    for (int j = 0; j < tempArrayList.size() &&
                            duplicateBilling == null; j++) {
                        
                        Billing tempBilling = tempArrayList.get(j);
                        if (tempBilling.equals(b)) {
                            
                            duplicateBilling = tempBilling;
                        }
                    }
                    if (duplicateBilling == null) {
                        tempArrayList.add(b);
                    }
                }
            }
            if (duplicateBilling != null) {
                duplicateBilling.IncrementVisitCounter();
            }
            else if (!patientFound) {
                ArrayList<Billing> tempArrayList = new ArrayList<>();
                tempArrayList.add(b);
                this.billingList.add(tempArrayList);
            }
        }
        totalStoredBillings++;
        this.printBillingList();
    }
    /**
     * Prints all patients and the doctors they use into the billing area.
     */
    private void printBillingList() {
        
        billListingArea.setText("");
        for (ArrayList<Billing> patientList : billingList) {
            
            Patient p = patientList.get(0).getPatient();
            billListingArea.append("Patient - " + p.getName() + 
                    " | ID# - " + p.getID() + '\n');
            
            for (Billing b : patientList) {
                
                Doctor d = b.getDoctor();
                Double visitFee = d.getOfficeVisitFee();
                int timesVisited = b.getTimesVisited();
                Double totalCost = timesVisited * visitFee;
                billListingArea.append("\tDoctor - " + d.getName() + 
                        " | Appointment Fee - $" + visitFee + 
                        "\n\t\tSpecialty - " + SPECIALTY_LIST[d.getSpecialty()] +
                        " | Times Visited - " + timesVisited + 
                        "\n\t\tTotal Cost - $" + totalCost + '\n'); 
            }
        }
    }
    
    //Private Object Classes
    
    /**
     * Base class used as foundation for Doctor and Patient classes.
     */
    private abstract class Person {
        
        //Member Variables
        
        private String name;
        
        //Constructors
        
        /**
         * Base constructor that sets name to empty string.
         */
        public Person() {
            initialize("");
        }
        /**
         * @param name Sets new Person's name
         */
        public Person(String name) {
            initialize(name);
        }
        
        //Getters and Setters
        
        /**
         * Returns Person's name.
         * @return Person's name.
         */
        public String getName() {
            return this.name;
        }
        /**
         * Changes Person's name.
         * @param name Person's name.
         */
        public void setName(String name) {
            this.name = name;
        }
        
        //Additonal Methods
        
        /**
         * Used to set all variables in the class, complete with validation
         * where necessary. Used for constructors.
         */
        private void initialize(String name) {
            this.setName(name);
        }
        /**
         * Checks if another Person instance is equal to current instance.
         * @param p Another Person instance.
         * @return True if instances are the same, false if not.
         */
        public boolean equals(Person p) {
            return this.name.equals(p.getName());
        }
    }
    
    /**
     * Describes doctor instances, including name, specialty, and appointment fees.
     */
    private class Doctor extends Person {
        
        //Member Variables
        
        private int specialty;
        private double officeVisitFee;
        
        //Constructors
        
        /**
         * Base constructor. Sets member variables to default values.
         */
        public Doctor() {
            initialize("", -1, 0.0);
        }
        /**
         * Constructor that sets all member variables. 
         * @param name Doctor's name as string.
         * @param specialty Doctor specialty as corresponding integer value. 
         * Specialty values: 0 - Pediatrician, 1 - Obstetrician, 
         * 2 - General Practitioner, 3 - Primary Care Physician, 4 - Gynecologist
         * @param officeVisitFee Doctor's appointment fee as double.
         */
        public Doctor(String name, int specialty, double officeVisitFee) {
            initialize(name, specialty, officeVisitFee);
        }
        
        //Getters and Setters
        
        /**
         * Get value corresponding to doctor's specialty.
         * @return Doctor specialty as corresponding integer value.  
         * Specialty values: 0 - Pediatrician, 1 - Obstetrician, 
         * 2 - General Practitioner, 3 - Primary Care Physician, 4 - Gynecologist
         */
        public int getSpecialty() {
            return this.specialty;
        }
        /**
         * Get appointment fee.
         * @return Doctor's appointment fee as double.
         */
        public double getOfficeVisitFee() {
            return this.officeVisitFee;
        }
        
        /**
         * Set value corresponding to specialty.
         * @param specialty Doctor specialty as corresponding integer value. 
         * Specialty values: 0 - Pediatrician, 1 - Obstetrician, 
         * 2 - General Practitioner, 3 - Primary Care Physician, 4 - Gynecologist
         */
        public void setSpecialty(int specialty) {
            try {
                if (specialty >= 0 && specialty < SPECIALTY_LIST.length)
                    this.specialty = specialty;
                else
                    throw new IndexOutOfBoundsException(
                        "Error in Doctor.setSpecialty: no specialty of that type."); 
            }
            catch (IndexOutOfBoundsException ex) {
                exceptionLog.add(ex.getMessage());
            }
        }
        /**
         * Set appointment fee.
         * @param officeVisitFee Doctor's appointment fee as double. 
         */
        public void setOfficeVisitFee(double officeVisitFee) {
            try {
                if (officeVisitFee > 0)
                    this.officeVisitFee = officeVisitFee;
                else 
                    throw new IllegalArgumentException("Office visit fee "
                            + "cannot be less than 0.");
            }
            catch (IllegalArgumentException ex) {
                exceptionLog.add(ex.getMessage());
            }
        }
        
        //Additional Methods
        
        /**
         * Used to set all variables in the class, complete with validation
         * where necessary. Used for constructors.
         * @param name Doctor's name as string.
         * @param specialty Doctor specialty as corresponding integer value. 
         * Specialty values: 0 - Pediatrician, 1 - Obstetrician, 
         * 2 - General Practitioner, 3 - Primary Care Physician, 4 - Gynecologist
         * @param officeVisitFee Doctor's appointment fee as double.
         */
        private void initialize(String name, int specialty, 
                                double officeVisitFee) {
            super.initialize(name);
            this.setSpecialty(specialty);
            this.setOfficeVisitFee(officeVisitFee);
        }
        /**
         * Checks if another Doctor instance is equal to current instance.
         * @param d Another Doctor instance.
         * @return True if instances are the same, false if not.
         */
        public boolean equals(Doctor d) {
            return super.name.equals(d.getName()) &&
                    this.specialty == d.getSpecialty() &&
                    this.officeVisitFee == d.getOfficeVisitFee();
        }
    }
        
    /**
     * Describes patient instances, including name and ID number.
     */
    private class Patient extends Person {
        
        //Member Variables
        
        private String ID;
        
        //Constructors
        
        /**
         * Base constructor. Sets member variables to default values.
         */
        public Patient() {
            initialize("", "00000000");
        }
        /**
         * Constructor that sets all member variables. 
         * @param name Patient's name as a String.
         * @param ID Patient's identification number as an 8-digit String.
         */
        public Patient(String name, String ID) {
            initialize(name, ID);
        }
        
        //Getters and Setters
        
        /**
         * Get patient identification number.
         * @return Patient's identification number as an 8-digit String.
         */
        public String getID() {
            return this.ID;
        }
        
        /**
         * Set patient identification number.
         * @param ID Patient's identification number as an 8-digit String.
         */
        public void setID(String ID) {
            try {
                if (ID.length() != PATIENT_ID_LENGTH) 
                    throw new IllegalArgumentException(
                        "Patient ID must be 8 digits.");
                else {
                    boolean valid = true;
                    for (int i = 0; i < PATIENT_ID_LENGTH; i++) {
                        if (!Character.isDigit(ID.charAt(i)))
                            valid = false;
                    }
                    if (valid)
                        this.ID = ID;
                    else
                        throw new IllegalArgumentException(
                        "Patient ID must only use digits 0-9.");
                }           
            }
            catch (IllegalArgumentException ex) {
                exceptionLog.add(ex.getMessage());
            }
        }
        
        //Additonal Methods
        
        /**
         * Used to set all variables in the class, complete with validation
         * where necessary. Used for constructors.
         * @param name Patient's name as a String.
         * @param ID Patient's identification number as an 8-digit String.
         */
        private void initialize(String name, String ID) {
            super.initialize(name);
            this.setID(ID);
        }
        /**
         * Checks if another Patient instance is equal to current instance.
         * @param p Another Patient instance.
         * @return True if instances are the same, false if not.
         */
        public boolean equals(Patient p) {
            return super.name.equals(p.getName()) &&
                    this.ID.equals(p.getID());
        }
    }
    
    /**
     * Describes a pending transaction between a set of Doctor and Patient
     * classes.
     */
    private class Billing {
        
        //Member Variables
        
        private Patient p;
        private Doctor d;
        private Double fee;
        private int timesVisited;
        
        //Constructors
        
        /**
         * Creates a transaction between a passed set of Doctor and Patient
         * classes.
         * @param d A Doctor instance.
         * @param p A Patient instance.
         */
        public Billing(Doctor d, Patient p) {
            initialize(d, p);
        }
        
        //Getters and Setters
        
        /**
         * Get Doctor instance.
         * @return A Doctor instance.
         */
        public Doctor getDoctor() {
            return this.d;
        }
        /**
         * Get Patient instance.
         * @return A Patient instance.
         */
        public Patient getPatient() {
            return this.p;
        }
        /**
         * Get transaction fee.
         * @return Fee as a double.
         */
        public double getFee() {
            return this.fee;
        }
        /**
         * Get times visited.
         * @return Times visited as integer.
         */
        public int getTimesVisited() {
            return this.timesVisited;
        }
        
        /**
         * Set Doctor instance.
         * @param d A Doctor instance.
         */
        public void setDoctor(Doctor d) {
            this.d = d;
            fee = d.getOfficeVisitFee();
        }
        /**
         * Set Patient instance.
         * @param p A Patient instance.
         */
        public void setPatient(Patient p) {
            this.p = p;
        }
        
        //Additional Methods
        
        /**
         * Used to set all variables in the class, complete with validation
         * where necessary. Used for constructors.
         * @param d A Doctor instance
         * @param p A Patient instance
         */
        private void initialize(Doctor d, Patient p) {
            this.setDoctor(d);
            this.setPatient(p);
            timesVisited = 1;
        }
        /**
         * Checks if another Billing instance is equal to current instance.
         * @param b Another Billing instance.
         * @return True if instances are the same, false if not.
         */
        public boolean equals(Billing b) {
            return this.d.equals(b.getDoctor()) &&
                    this.p.equals(b.getPatient()) &&
                    this.fee == b.getFee();
        }
        public void IncrementVisitCounter() {
            timesVisited++;
        }
    }
    
}

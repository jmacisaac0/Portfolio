
package assignment3;

/**
 *
 * @author Julian MacIsaac
 */
public class Assignment3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Frame Setup
        Assignment3GUI gui = new Assignment3GUI();
        gui.generateGUI();
    }
    
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Preferred_Customer
{
    abstract class Person
    {
        string name { get; set; }
        string address { get; set; }
        string phoneNum { get; set; }

        public Person()
        {
            name = "";
            address = "";
            phoneNum = "";
        }
        public Person(string name, string address, string phoneNum)
        {
            this.name = name;
            this.address = address;
            this.phoneNum = phoneNum;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Preferred_Customer
{


    class PreferredCustomer : Customer
    {
        decimal purchaseAmt { get; set; }
        private double discountPrcnt;
        public PreferredCustomer() : base()
        {
            purchaseAmt = 0m;
            discountPrcnt = 0.0;
        }
        public PreferredCustomer(string name, string address, string phoneNum, string custNum, bool onMailList,             
               decimal purchaseAmt) : base(name, address, phoneNum, custNum, onMailList)
        {
            this.purchaseAmt = purchaseAmt;
        }

        private void CalcDiscount(out double discountPrcnt)
        {
            if (purchaseAmt >= 2000) { discountPrcnt = 0.05; }
            else if (purchaseAmt >= 1500) { discountPrcnt = 0.06; }
            else if (purchaseAmt >= 1000) { discountPrcnt = 0.07; }
            else if (purchaseAmt >= 500) { discountPrcnt = 0.10; }
            else { discountPrcnt = 0.00; }
        }
    }
}

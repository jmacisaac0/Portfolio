﻿namespace Preferred_Customer
{
    partial class CustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.custGrp = new System.Windows.Forms.GroupBox();
            this.lbl4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lbl5 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lbl6 = new System.Windows.Forms.Label();
            this.enterBtn = new System.Windows.Forms.Button();
            this.chkBtn = new System.Windows.Forms.Button();
            this.custGrp.SuspendLayout();
            this.SuspendLayout();
            // 
            // custGrp
            // 
            this.custGrp.Controls.Add(this.lbl4);
            this.custGrp.Controls.Add(this.textBox1);
            this.custGrp.Controls.Add(this.textBox2);
            this.custGrp.Controls.Add(this.lbl5);
            this.custGrp.Controls.Add(this.textBox3);
            this.custGrp.Controls.Add(this.lbl6);
            this.custGrp.Location = new System.Drawing.Point(12, 12);
            this.custGrp.Name = "custGrp";
            this.custGrp.Size = new System.Drawing.Size(263, 112);
            this.custGrp.TabIndex = 13;
            this.custGrp.TabStop = false;
            this.custGrp.Text = "Customer Information";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Location = new System.Drawing.Point(20, 27);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(35, 13);
            this.lbl4.TabIndex = 12;
            this.lbl4.Text = "Name";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(139, 24);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 13;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(139, 76);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 17;
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Location = new System.Drawing.Point(20, 53);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(45, 13);
            this.lbl5.TabIndex = 14;
            this.lbl5.Text = "Address";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(139, 50);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 16;
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Location = new System.Drawing.Point(20, 79);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(78, 13);
            this.lbl6.TabIndex = 15;
            this.lbl6.Text = "Phone Number";
            // 
            // enterBtn
            // 
            this.enterBtn.Location = new System.Drawing.Point(12, 130);
            this.enterBtn.Name = "enterBtn";
            this.enterBtn.Size = new System.Drawing.Size(128, 23);
            this.enterBtn.TabIndex = 14;
            this.enterBtn.Text = "Enter";
            this.enterBtn.UseVisualStyleBackColor = true;
            // 
            // chkBtn
            // 
            this.chkBtn.Location = new System.Drawing.Point(147, 130);
            this.chkBtn.Name = "chkBtn";
            this.chkBtn.Size = new System.Drawing.Size(128, 23);
            this.chkBtn.TabIndex = 15;
            this.chkBtn.Text = "Check";
            this.chkBtn.UseVisualStyleBackColor = true;
            // 
            // CustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 160);
            this.Controls.Add(this.chkBtn);
            this.Controls.Add(this.enterBtn);
            this.Controls.Add(this.custGrp);
            this.Name = "CustomerForm";
            this.Text = "Customer";
            this.custGrp.ResumeLayout(false);
            this.custGrp.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox custGrp;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Button enterBtn;
        private System.Windows.Forms.Button chkBtn;
    }
}
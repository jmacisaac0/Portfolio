﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Preferred_Customer
{
    class Customer : Person
    {
        string custNum { get; set; }
        bool onMailList { get; set; }
        public Customer() : base()
        {
            custNum = "";
            onMailList = false;
        }
        public Customer(string name, string address, string phoneNum, string custNum, bool onMailList) 
               : base(name, address, phoneNum)
        {
            this.custNum = custNum;
            this.onMailList = onMailList;
        }
    }
}

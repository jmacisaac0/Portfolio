﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Preferred_Customer
{
    abstract class Person
    {
        string name;
        string address;
        string phoneNum;
    }
}

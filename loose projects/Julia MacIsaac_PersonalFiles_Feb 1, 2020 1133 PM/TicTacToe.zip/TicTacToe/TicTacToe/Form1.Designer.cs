﻿namespace TicTacToe
{
    partial class TictactoeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NWBtn = new System.Windows.Forms.Button();
            this.EBtn = new System.Windows.Forms.Button();
            this.SBtn = new System.Windows.Forms.Button();
            this.SWBtn = new System.Windows.Forms.Button();
            this.SEBtn = new System.Windows.Forms.Button();
            this.CenterBtn = new System.Windows.Forms.Button();
            this.WBtn = new System.Windows.Forms.Button();
            this.NEBtn = new System.Windows.Forms.Button();
            this.NBtn = new System.Windows.Forms.Button();
            this.NewAutoGameBtn = new System.Windows.Forms.Button();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.NewSingleGameBtn = new System.Windows.Forms.Button();
            this.NewMultiGameBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // NWBtn
            // 
            this.NWBtn.BackColor = System.Drawing.Color.Black;
            this.NWBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NWBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.NWBtn.FlatAppearance.BorderSize = 10;
            this.NWBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.NWBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NWBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.NWBtn.ForeColor = System.Drawing.Color.White;
            this.NWBtn.Location = new System.Drawing.Point(12, 12);
            this.NWBtn.Name = "NWBtn";
            this.NWBtn.Size = new System.Drawing.Size(150, 150);
            this.NWBtn.TabIndex = 0;
            this.NWBtn.UseVisualStyleBackColor = false;
            // 
            // EBtn
            // 
            this.EBtn.BackColor = System.Drawing.Color.Black;
            this.EBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.EBtn.FlatAppearance.BorderSize = 10;
            this.EBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.EBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.EBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.EBtn.ForeColor = System.Drawing.Color.White;
            this.EBtn.Location = new System.Drawing.Point(324, 168);
            this.EBtn.Name = "EBtn";
            this.EBtn.Size = new System.Drawing.Size(150, 150);
            this.EBtn.TabIndex = 1;
            this.EBtn.UseVisualStyleBackColor = false;
            // 
            // SBtn
            // 
            this.SBtn.BackColor = System.Drawing.Color.Black;
            this.SBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.SBtn.FlatAppearance.BorderSize = 10;
            this.SBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.SBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.SBtn.ForeColor = System.Drawing.Color.White;
            this.SBtn.Location = new System.Drawing.Point(168, 324);
            this.SBtn.Name = "SBtn";
            this.SBtn.Size = new System.Drawing.Size(150, 150);
            this.SBtn.TabIndex = 2;
            this.SBtn.UseVisualStyleBackColor = false;
            // 
            // SWBtn
            // 
            this.SWBtn.BackColor = System.Drawing.Color.Black;
            this.SWBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SWBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.SWBtn.FlatAppearance.BorderSize = 10;
            this.SWBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.SWBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SWBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.SWBtn.ForeColor = System.Drawing.Color.White;
            this.SWBtn.Location = new System.Drawing.Point(12, 324);
            this.SWBtn.Name = "SWBtn";
            this.SWBtn.Size = new System.Drawing.Size(150, 150);
            this.SWBtn.TabIndex = 3;
            this.SWBtn.UseVisualStyleBackColor = false;
            // 
            // SEBtn
            // 
            this.SEBtn.BackColor = System.Drawing.Color.Black;
            this.SEBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SEBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.SEBtn.FlatAppearance.BorderSize = 10;
            this.SEBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.SEBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SEBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.SEBtn.ForeColor = System.Drawing.Color.White;
            this.SEBtn.Location = new System.Drawing.Point(324, 324);
            this.SEBtn.Name = "SEBtn";
            this.SEBtn.Size = new System.Drawing.Size(150, 150);
            this.SEBtn.TabIndex = 4;
            this.SEBtn.UseVisualStyleBackColor = false;
            // 
            // CenterBtn
            // 
            this.CenterBtn.BackColor = System.Drawing.Color.Black;
            this.CenterBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CenterBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.CenterBtn.FlatAppearance.BorderSize = 10;
            this.CenterBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.CenterBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CenterBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.CenterBtn.ForeColor = System.Drawing.Color.White;
            this.CenterBtn.Location = new System.Drawing.Point(168, 168);
            this.CenterBtn.Name = "CenterBtn";
            this.CenterBtn.Size = new System.Drawing.Size(150, 150);
            this.CenterBtn.TabIndex = 5;
            this.CenterBtn.UseVisualStyleBackColor = false;
            // 
            // WBtn
            // 
            this.WBtn.BackColor = System.Drawing.Color.Black;
            this.WBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.WBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.WBtn.FlatAppearance.BorderSize = 10;
            this.WBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.WBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.WBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.WBtn.ForeColor = System.Drawing.Color.White;
            this.WBtn.Location = new System.Drawing.Point(12, 168);
            this.WBtn.Name = "WBtn";
            this.WBtn.Size = new System.Drawing.Size(150, 150);
            this.WBtn.TabIndex = 6;
            this.WBtn.UseVisualStyleBackColor = false;
            // 
            // NEBtn
            // 
            this.NEBtn.BackColor = System.Drawing.Color.Black;
            this.NEBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NEBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.NEBtn.FlatAppearance.BorderSize = 10;
            this.NEBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.NEBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NEBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.NEBtn.ForeColor = System.Drawing.Color.White;
            this.NEBtn.Location = new System.Drawing.Point(324, 12);
            this.NEBtn.Name = "NEBtn";
            this.NEBtn.Size = new System.Drawing.Size(150, 150);
            this.NEBtn.TabIndex = 7;
            this.NEBtn.UseVisualStyleBackColor = false;
            // 
            // NBtn
            // 
            this.NBtn.BackColor = System.Drawing.Color.Black;
            this.NBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.NBtn.FlatAppearance.BorderSize = 10;
            this.NBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.NBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.NBtn.ForeColor = System.Drawing.Color.White;
            this.NBtn.Location = new System.Drawing.Point(168, 12);
            this.NBtn.Name = "NBtn";
            this.NBtn.Size = new System.Drawing.Size(150, 150);
            this.NBtn.TabIndex = 8;
            this.NBtn.UseVisualStyleBackColor = false;
            // 
            // NewAutoGameBtn
            // 
            this.NewAutoGameBtn.AutoEllipsis = true;
            this.NewAutoGameBtn.BackColor = System.Drawing.Color.Black;
            this.NewAutoGameBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NewAutoGameBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.NewAutoGameBtn.FlatAppearance.BorderSize = 10;
            this.NewAutoGameBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NewAutoGameBtn.Font = new System.Drawing.Font("Rockwell Extra Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewAutoGameBtn.ForeColor = System.Drawing.Color.White;
            this.NewAutoGameBtn.Location = new System.Drawing.Point(12, 480);
            this.NewAutoGameBtn.Name = "NewAutoGameBtn";
            this.NewAutoGameBtn.Size = new System.Drawing.Size(230, 34);
            this.NewAutoGameBtn.TabIndex = 9;
            this.NewAutoGameBtn.Text = "New Auto Game";
            this.NewAutoGameBtn.UseVisualStyleBackColor = false;
            this.NewAutoGameBtn.Click += new System.EventHandler(this.NewAutoGameBtn_Click);
            // 
            // ExitBtn
            // 
            this.ExitBtn.AutoEllipsis = true;
            this.ExitBtn.BackColor = System.Drawing.Color.Black;
            this.ExitBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ExitBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.ExitBtn.FlatAppearance.BorderSize = 10;
            this.ExitBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ExitBtn.Font = new System.Drawing.Font("Rockwell Extra Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitBtn.ForeColor = System.Drawing.Color.White;
            this.ExitBtn.Location = new System.Drawing.Point(244, 520);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(230, 34);
            this.ExitBtn.TabIndex = 10;
            this.ExitBtn.Text = "Exit";
            this.ExitBtn.UseVisualStyleBackColor = false;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // NewSingleGameBtn
            // 
            this.NewSingleGameBtn.AutoEllipsis = true;
            this.NewSingleGameBtn.BackColor = System.Drawing.Color.Black;
            this.NewSingleGameBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NewSingleGameBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.NewSingleGameBtn.FlatAppearance.BorderSize = 10;
            this.NewSingleGameBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NewSingleGameBtn.Font = new System.Drawing.Font("Rockwell Extra Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewSingleGameBtn.ForeColor = System.Drawing.Color.White;
            this.NewSingleGameBtn.Location = new System.Drawing.Point(244, 480);
            this.NewSingleGameBtn.Name = "NewSingleGameBtn";
            this.NewSingleGameBtn.Size = new System.Drawing.Size(230, 34);
            this.NewSingleGameBtn.TabIndex = 11;
            this.NewSingleGameBtn.Text = "Single Player Game";
            this.NewSingleGameBtn.UseVisualStyleBackColor = false;
            this.NewSingleGameBtn.Click += new System.EventHandler(this.NewSingleGameBtn_Click);
            // 
            // NewMultiGameBtn
            // 
            this.NewMultiGameBtn.AutoEllipsis = true;
            this.NewMultiGameBtn.BackColor = System.Drawing.Color.Black;
            this.NewMultiGameBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NewMultiGameBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.NewMultiGameBtn.FlatAppearance.BorderSize = 10;
            this.NewMultiGameBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NewMultiGameBtn.Font = new System.Drawing.Font("Rockwell Extra Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewMultiGameBtn.ForeColor = System.Drawing.Color.White;
            this.NewMultiGameBtn.Location = new System.Drawing.Point(12, 520);
            this.NewMultiGameBtn.Name = "NewMultiGameBtn";
            this.NewMultiGameBtn.Size = new System.Drawing.Size(230, 34);
            this.NewMultiGameBtn.TabIndex = 12;
            this.NewMultiGameBtn.Text = "Multiplayer Game";
            this.NewMultiGameBtn.UseVisualStyleBackColor = false;
            this.NewMultiGameBtn.Click += new System.EventHandler(this.NewMultiGameBtn_Click);
            // 
            // TictactoeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(484, 562);
            this.Controls.Add(this.NewMultiGameBtn);
            this.Controls.Add(this.NewSingleGameBtn);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.NewAutoGameBtn);
            this.Controls.Add(this.NBtn);
            this.Controls.Add(this.NEBtn);
            this.Controls.Add(this.WBtn);
            this.Controls.Add(this.CenterBtn);
            this.Controls.Add(this.SEBtn);
            this.Controls.Add(this.SWBtn);
            this.Controls.Add(this.SBtn);
            this.Controls.Add(this.EBtn);
            this.Controls.Add(this.NWBtn);
            this.Name = "TictactoeForm";
            this.Text = "Tic Tac Toe";
            this.Load += new System.EventHandler(this.TictactoeForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button NWBtn;
        private System.Windows.Forms.Button EBtn;
        private System.Windows.Forms.Button SBtn;
        private System.Windows.Forms.Button SWBtn;
        private System.Windows.Forms.Button SEBtn;
        private System.Windows.Forms.Button CenterBtn;
        private System.Windows.Forms.Button WBtn;
        private System.Windows.Forms.Button NEBtn;
        private System.Windows.Forms.Button NBtn;
        private System.Windows.Forms.Button NewAutoGameBtn;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Button NewSingleGameBtn;
        private System.Windows.Forms.Button NewMultiGameBtn;
    }
}


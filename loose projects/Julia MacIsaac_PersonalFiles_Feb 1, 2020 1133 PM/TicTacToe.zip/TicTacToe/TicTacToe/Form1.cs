﻿/*
 * Julian MacIsaac
 * Tic Tac Toe
 * Hands on Test 4
 */ 

using System;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class TictactoeForm : Form
    {
        enum Player {x, o, none}
        enum gameType { none, single, multi, auto}
        int BOARD_DIMENSION = 3;
        BoardSpace[,] btnArray;
        int currentGame = (int)gameType.none;
        bool IsP1Turn = false;
        bool IsP2Turn = false;

        //form objects
        public TictactoeForm() { InitializeComponent(); }

        private void TictactoeForm_Load(object sender, EventArgs e)
        {
            //used to structure board in code
            btnArray = new BoardSpace[BOARD_DIMENSION, BOARD_DIMENSION];
            btnArray[0,0].setButton(NWBtn);
            btnArray[0,1].setButton(NBtn);
            btnArray[0,2].setButton(NEBtn);
            btnArray[1,0].setButton(WBtn);
            btnArray[1,1].setButton(CenterBtn);
            btnArray[1,2].setButton(EBtn);
            btnArray[2,0].setButton(SWBtn);
            btnArray[2,1].setButton(SBtn);
            btnArray[2,2].setButton(SEBtn);
        }

        //buttons
        private void NewAutoGameBtn_Click(object sender, EventArgs e) { RunAutoGame(); }
        private void NewSingleGameBtn_Click(object sender, EventArgs e) { RunSinglePlayerGame(); }
        private void NewMultiGameBtn_Click(object sender, EventArgs e) { RunMultiplayerGame(); }
        private void ExitBtn_Click(object sender, EventArgs e) { Application.Exit(); }


        //methods
        private void RunAutoGame()
        {
            if (StartNewGame((int)gameType.auto))
            {
                currentGame = (int)gameType.auto;
                GenerateRandomBoard();
                //IsWinner finds the winner of the passed player on the passed board and returns a boolean value, which
                //is used to by the DisplayWinner method.
                DisplayWinner(IsWinner((int)Player.x), IsWinner((int)Player.o));
                currentGame = (int)gameType.none;
            }
        }
        private void RunSinglePlayerGame()
        {
            if (StartNewGame((int)gameType.single))
            {
                GenerateEmptyBoard();
                currentGame = (int)gameType.single;
            }
        }
        private void RunMultiplayerGame()
        {
            if (StartNewGame((int)gameType.multi))
            {
                GenerateEmptyBoard();
                currentGame = (int)gameType.multi;
            }
        }

        private void GenerateRandomBoard()
        {
            Random r = new Random();
            //value of 0 or 1 is placed in each element, which correspond to x and o, respectively
            int temp;
            for (int i = 0; i < BOARD_DIMENSION; i++)
            {
                for (int j = 0; j < BOARD_DIMENSION; j++)
                {
                    temp = r.Next(2);
                    btnArray[i,j].setPlayerVal(temp);
                    //updates the corresponding button to display x or o
                    RefreshBtn(btnArray[i,j]);
                }
            }
        }
        private void GenerateEmptyBoard()
        {
            for (int i = 0; i < BOARD_DIMENSION; i++)
            {
                for (int j = 0; j < BOARD_DIMENSION; i++)
                {
                    btnArray[i, j].setPlayerVal((int)Player.none);
                    RefreshBtn(btnArray[i, j]);
                }
            }
        }

        private bool StartNewGame(int type) 
        {
            /*
            DialogResult prompt = new DialogResult();
            prompt = DialogResult.No;
            //if type = 0, then quit prompt, if 1 then play again prompt
            if (choice == 0)
            {
                prompt = MessageBox.Show("Do you want to quit the current game?", "Quit?",
                                       MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            }
            if (choice == 1)
            {
                prompt = MessageBox.Show("Do you want to play again?", "Play Again?",
                                       MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            }
            else
            {
                MessageBox.Show("Error displaying prompt.\n " +
                                "Pass 0 for Quit Game prompt.\n " +
                                "Pass 1 for Run Again prompt.\n",
                                "Prompt Display Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (prompt == DialogResult.Yes) { return true; }
            else { return false; }
            bool run = false;
            if (currentGame != (int)gameType.none)
            {
                run = NewGamePrompt(0);
            }
            else { run = true; }

            return run;
        }
        TODO */

        private void RefreshBtn(BoardSpace space)
        {
            //if 0, the button at the passed coordinates will display x, else it will display o
            if (space.getPlayerVal() == (int)Player.x) { space.getButton().Text = "X"; }
            else if (space.getPlayerVal() == (int)Player.o) { space.getButton().Text = "O"; }
            else if (space.getPlayerVal() == (int)Player.none) { space.getButton().Text = ""; }
            else
            {
                MessageBox.Show("There was a logical error in method RefreshBtn",
                                   "Error", 
                                   MessageBoxButtons.OK, 
                                   MessageBoxIcon.Error);
            }
        }

        private bool IsWinner(int player)
        {
            bool win = false;

            /*
             * starts from center sqaure, checking all possible wins using the center.
             * then checks top left and bottom right corners to find the other possible wins
             * All wins must go through one or more of these squares
             */ 
            if (btnArray[1,1].getPlayerVal() == player)
            {
                if (btnArray[0,1].getPlayerVal() == player && btnArray[2, 1].getPlayerVal() == player) { win = true; }
                else if (btnArray[0,0].getPlayerVal() == player && btnArray[2,2].getPlayerVal() == player) { win = true; }
                else if (btnArray[1,0].getPlayerVal() == player && btnArray[1,2].getPlayerVal() == player) { win = true; }
                else if (btnArray[2,0].getPlayerVal() == player && btnArray[0,2].getPlayerVal() == player) { win = true; }
            }
            if (!win && btnArray[0,0].getPlayerVal() == player)
            {
                if (btnArray[0,1].getPlayerVal() == player && btnArray[0,2].getPlayerVal() == player) { win = true; }
                else if (btnArray[1,0].getPlayerVal() == player && btnArray[2,0].getPlayerVal() == player) { win = true; }
            }
            if (!win && btnArray[2,2].getPlayerVal() == player)
            {
                if (btnArray[2,0].getPlayerVal() == player && btnArray[2,1].getPlayerVal() == player) { win = true; }
                else if (btnArray[0,2].getPlayerVal() == player && btnArray[1,2].getPlayerVal() == player) { win = true; }
            }
            return win;
        }

        private void DisplayWinner(bool xWin, bool oWin)
        {
            if (xWin == true && oWin == true) {
                MessageBox.Show("The game was a draw.", "Draw", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (xWin == true)
            {
                MessageBox.Show("X wins!", "X win", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (oWin == true)
            {
                MessageBox.Show("O wins!", "O win", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                MessageBox.Show("Neither player won", "Draw", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }

        }
        
        /* REMOVE
        private bool NewGamePrompt(int choice)
        {
            DialogResult prompt = new DialogResult();
            prompt = DialogResult.No;
            //if type = 0, then quit prompt, if 1 then play again prompt
            if (choice == 0)
            {
                prompt = MessageBox.Show("Do you want to quit the current game?", "Quit?",
                                       MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            }
            if (choice == 1)
            {
                prompt = MessageBox.Show("Do you want to play again?", "Play Again?",
                                       MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            }
            else
            {
                MessageBox.Show("Error displaying prompt.\n " +
                                "Pass 0 for Quit Game prompt.\n " +
                                "Pass 1 for Run Again prompt.\n", 
                                "Prompt Display Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if (prompt == DialogResult.Yes) { return true; }
            else { return false; } 
        }
        */

        //classes
        struct BoardSpace
        {
            private Button btn;
            private int playerVal;

            //getters
            public Button getButton() { return btn; }
            public int getPlayerVal() { return playerVal; }

            //setters
            public void setButton(Button inBtn) { btn = inBtn; }
            public void setPlayerVal(int val) { playerVal = val; }
        }
    }
}

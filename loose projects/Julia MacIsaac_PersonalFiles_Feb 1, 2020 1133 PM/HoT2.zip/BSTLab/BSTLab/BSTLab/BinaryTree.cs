﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BSTLab
{
    public class BinaryTree<T>
    {
        private BinaryTreeNode<T> root;

        public BinaryTree()
        {
            root = null;
        }

        public virtual void Clear()
        {
            root = null;
        }

        public BinaryTreeNode<T> Root
        {
            get
            {
                return root;
            }

            set
            {
                root = value;
            }
        }

        private string InOrder(BinaryTreeNode<T> current)
        {
            //'LVR' traversal
            string temp = "";
            if (current.Left != null)
            {
                temp += (InOrder(current.Left).Trim() + " ");
            }
            if (current != null)
            {
                temp += (current.ToString().Trim() + " ");
            }
            if (current.Right != null)
            {
                temp += (InOrder(current.Right).Trim() + " ");
            }
            //This code will need to be updated for HandsOnTest2 and the Binary Search Tree Lab.
            return temp;
        }

        public string InOrderTrav()
        {
            //This code will need to be updated for HandsOnTest2 and the Binary Search Tree Lab.
            return InOrder(root);
        }

        private string PreOrder(BinaryTreeNode<T> current)
        {
            //'VLR' traversal
            string temp = "";
            if (current != null)
            {
                temp += (current.ToString().Trim() + " ");
            }
            if (current.Left != null)
            {
                temp += (PreOrder(current.Left).Trim() + " ");
            }
            if (current.Right != null)
            {
                temp += (PreOrder(current.Right).Trim() + " ");
            }
            //This code will need to be updated for HandsOnTest2.
            return temp;
        }

        public string PreOrderTrav()
        {
            //This code will need to be updated for HandsOnTest2.
            return PreOrder(root);
        }

        private string PostOrder(BinaryTreeNode<T> current)
        {
            //'LRV' traversal
            string temp = "";
            if (current.Left != null)
            {
                temp += (PostOrder(current.Left).Trim() + " ");
            }
            if (current.Right != null)
            {
                temp += (PostOrder(current.Right).Trim() + " ");
            }
            if (current != null)
            {
                temp += (current.ToString().Trim() + " ");
            }
            //This code will need to be updated for HandsOnTest2.
            return temp;
        }

        public string PostOrderTrav()
        {
            //This code will need to be updated for HandsOnTest2.
            return PostOrder(root);
        }
        
        public override string ToString()
        {
            return InOrder(root);
        }
    }
}

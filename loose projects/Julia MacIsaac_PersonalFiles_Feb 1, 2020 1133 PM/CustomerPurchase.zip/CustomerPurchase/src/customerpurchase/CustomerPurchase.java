
package customerpurchase;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CustomerPurchase extends JFrame implements ActionListener, WindowListener {
    
    int totalItemsPurchased;
    String totalItemsLabelString = "Total items purchased: ";
    
    BuyItemForm form2 = new BuyItemForm();
    
    JLabel totalItemsPurchasedLbl;
    JTextArea itemArea;
    JScrollPane itemAreaScrollPane;
    JButton addItemBtn;
    
    Container contentPane;
    
    public CustomerPurchase() {
       
        setSize(300, 300);
        setTitle("Customer Purchase");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        form2.addWindowListener(this);
        
        totalItemsPurchased = 0;
        
        contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        
        totalItemsPurchasedLbl = new JLabel(totalItemsLabelString + 
                totalItemsPurchased);
        contentPane.add(totalItemsPurchasedLbl, BorderLayout.NORTH);     
        itemArea = new JTextArea();
        itemAreaScrollPane = new JScrollPane(itemArea);
        contentPane.add(itemAreaScrollPane, BorderLayout.CENTER);
        addItemBtn = new JButton("Add Item");
        addItemBtn.setActionCommand("ADD");
        addItemBtn.addActionListener(this);
        contentPane.add(addItemBtn, BorderLayout.SOUTH);
    }
    
    public static void main(String[] args) {
        
        CustomerPurchase c = new CustomerPurchase();
        c.setVisible(true);
        
    }
    
    public void actionPerformed (ActionEvent e) {
        
        String actionCommand = e.getActionCommand();
        
        if (actionCommand.equals("ADD")) {    
               form2.SetItemName("");
               form2.SetItemPrice(0.0);
               form2.setVisible(true);
        }
        
    }
    public void windowActivated(WindowEvent e) {
        
    }
    public void windowClosed(WindowEvent e) {
        if (form2.readyToAdd) {
            addItem();
            form2.setReadyToAdd(false);
        }
    }
    public void windowClosing(WindowEvent e) {
        
    }
    public void windowDeactivated(WindowEvent e) {
        
    }
    public void windowDeiconified(WindowEvent e)
    {
        
    }
    public void windowIconified(WindowEvent e) {
        
    }
    public void windowOpened(WindowEvent e) {
        
    }
    
    private void addItem() {
        
        String line = form2.GetItemName() + ": " + 
        Double.toString(form2.GetItemPrice());
        itemArea.append(line + "\n");
        totalItemsPurchased++;
        totalItemsPurchasedLbl.setText(totalItemsLabelString + 
                Integer.toString(totalItemsPurchased));

    } 
    
    private class BuyItemForm extends JFrame implements ActionListener {
        
        String itemName;
        Double itemPrice;
        Boolean readyToAdd;
        
        JPanel inputPnl, buttonPnl;
        JButton addBtn, resetBtn, exitBtn;
        JLabel itemNameLbl, itemPriceLbl;
        JTextField itemNameTxtFld, itemPriceTxtFld;
        
        Container innerPane;
        
        public BuyItemForm() {
            
            setSize(300, 120);
            setTitle("Add new item purchase");
            setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            innerPane = getContentPane();
            innerPane.setLayout(new BorderLayout());
            
            inputPnl = new JPanel();
            inputPnl.setLayout(new GridLayout(2, 2));
            itemNameLbl = new JLabel("Enter item name: ");
            inputPnl.add(itemNameLbl);
            itemPriceLbl = new JLabel ("Enter item price: ");
            inputPnl.add(itemPriceLbl);
            itemNameTxtFld = new JTextField();
            inputPnl.add(itemNameTxtFld);
            itemPriceTxtFld = new JTextField();
            inputPnl.add(itemPriceTxtFld);
            innerPane.add(inputPnl, BorderLayout.CENTER);
            
            
            buttonPnl = new JPanel();
            buttonPnl.setLayout(new FlowLayout());
            addBtn = new JButton("Add");
            addBtn.addActionListener(this);
            buttonPnl.add(addBtn);
            resetBtn = new JButton("Reset");
            resetBtn.addActionListener(this);
            buttonPnl.add(resetBtn);
            exitBtn = new JButton("Exit");
            exitBtn.addActionListener(this);
            buttonPnl.add(exitBtn);
            innerPane.add(buttonPnl, BorderLayout.SOUTH);
            
            itemName = "";
            itemPrice = 0.0;
            readyToAdd = false;
            
        }
        
        public boolean readyToAdd() {
            return readyToAdd;
        }
        public void setReadyToAdd(boolean rta) {
            this.readyToAdd = rta;
        }
        public String GetItemName() {
            return itemName;
        }
        public double GetItemPrice() {
            return itemPrice;
        }
        public void SetItemName(String name) {
            this.itemName = name;
        }
        public void SetItemPrice(Double price) {
            this.itemPrice = price;
        }
        
        public boolean validNumber(String input) {
            boolean valid = true;
            if (!input.equals("")) {
                for (int i = 0; i < input.length(); i++) {
                    System.out.println(input.charAt(i));
                    if (!Character.isDigit(input.charAt(i)) && 
                            input.charAt(i) != '.') {
                        valid = false;
                    }
                }
            }
            else {
                valid = false;
            }
            return valid;
        }
        
        public void actionPerformed (ActionEvent e) {
        
            String actionCommand = e.getActionCommand();
            
            if (actionCommand.equals("Add")) {
                
                if(validNumber(itemPriceTxtFld.getText()) && 
                        !itemNameTxtFld.getText().equals("")) {
                    itemName = itemNameTxtFld.getText();
                    itemPrice = Double.parseDouble(itemPriceTxtFld.getText());
                    readyToAdd = true;
                    this.dispose();
                }
                else {
                    itemNameTxtFld.setText("Invalid");
                    itemPriceTxtFld.setText("Input");
                }
            }
            else if (actionCommand.equals("Reset")) {
                itemNameTxtFld.setText("");
                itemPriceTxtFld.setText("");
            }
            else if (actionCommand.equals("Exit")) {
                itemNameTxtFld.setText("");
                itemPriceTxtFld.setText("");
                this.dispose();
            }
            else {
                System.out.println("ERROR");
            }
            
        }
        
    }
}

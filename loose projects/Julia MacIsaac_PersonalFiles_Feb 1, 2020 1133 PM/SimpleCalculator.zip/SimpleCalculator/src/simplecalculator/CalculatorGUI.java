
package simplecalculator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CalculatorGUI extends JFrame implements ActionListener {
    
    JButton btnNum1, btnNum2, btnNum3, btnNum4, btnNum5, btnNum6, btnNum7, 
            btnNum8, btnNum9, btnAdd, btnSubtract, btnMultiply, btnDivide,
            btnClear, btnEnter;
    JLabel lblNumDisplay1, lblNumDisplay2, lblOperatorDisplay;
    JPanel pnlDisplay, pnlNumPad, pnlOperatorPad, pnlControl;
    Container contentPane;
    
    public CalculatorGUI() {    
        
        setSize(500,500);
        setTitle("Simple Calculator");
        
        contentPane = getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
        
        pnlDisplay = new JPanel();
        pnlDisplay.setLayout(new BoxLayout(pnlDisplay, BoxLayout.X_AXIS));
        lblNumDisplay1 = new JLabel("");
        lblOperatorDisplay = new JLabel("");
        lblNumDisplay2 = new JLabel("");
        pnlDisplay.add(lblNumDisplay1);
        pnlDisplay.add(lblOperatorDisplay);
        pnlDisplay.add(lblNumDisplay2);
        contentPane.add(pnlDisplay);
        
        pnlNumPad = new JPanel();
        pnlNumPad.setLayout(new GridLayout(3,3));
        btnNum1 = new JButton("1");
        btnNum2 = new JButton("2");
        btnNum3 = new JButton("3");
        btnNum4 = new JButton("4");
        btnNum5 = new JButton("5");
        btnNum6 = new JButton("6");
        btnNum7 = new JButton("7");
        btnNum8 = new JButton("8");
        btnNum9 = new JButton("9");
        btnNum1.addActionListener(this);
        btnNum2.addActionListener(this);
        btnNum3.addActionListener(this);
        btnNum4.addActionListener(this);
        btnNum5.addActionListener(this);
        btnNum6.addActionListener(this);
        btnNum7.addActionListener(this);
        btnNum8.addActionListener(this);
        btnNum9.addActionListener(this);
        pnlNumPad.add(btnNum1);
        pnlNumPad.add(btnNum2);
        pnlNumPad.add(btnNum3);
        pnlNumPad.add(btnNum4);
        pnlNumPad.add(btnNum5);
        pnlNumPad.add(btnNum6);
        pnlNumPad.add(btnNum7);
        pnlNumPad.add(btnNum8);
        pnlNumPad.add(btnNum9);
        contentPane.add(pnlNumPad);
        
        pnlOperatorPad = new JPanel();
        pnlOperatorPad.setLayout(new BoxLayout(pnlOperatorPad, 
                                               BoxLayout.X_AXIS));
        
        
        pnlControl = new JPanel();
        pnlControl.setLayout(new BoxLayout(pnlControl, BoxLayout.X_AXIS));
        
    }
    
    public void actionPerformed (ActionEvent e) {
        
    }
    
}

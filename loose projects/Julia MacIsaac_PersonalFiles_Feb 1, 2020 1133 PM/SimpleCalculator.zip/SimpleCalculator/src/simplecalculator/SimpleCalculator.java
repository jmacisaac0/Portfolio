
package simplecalculator;

public class SimpleCalculator {

    public static void main(String[] args) {
        
        CalculatorGUI gui = new CalculatorGUI();
        gui.setVisible(true);
        
    }
    
}


package athlete.program;

/**
 *
 * @author Julian MacIsaac
 */
public class AthleteProgram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        AthleteGUI gui = new AthleteGUI();
        gui.initialize();
        
    }
    
}

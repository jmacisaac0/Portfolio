/*
* Julian MacIsaac
* Lottery Application
*/

#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <vector>
using namespace std;



//function declarations
void PrintTitle();
bool ParseAndValidate(int, int&);
void printIntVector(vector<int>);

//global constants
const int LOTTERY_SIZE = 5;
//title data
const string TITLE = "Lottery Application";
const char FILL_CHAR = '-';
const int TITLE_WIDTH = 60;


int main() {
	
	//variables
	int input;
	int numCorrect = 0;
	//objects
	vector<int> lottery, guess, vectorCopy;
	vector<int>::iterator vectorIterator;

	//body
	//initialization
	PrintTitle();
	srand(time(NULL));	

	cout << "\nEnter the five digits of your lottery guess." << endl;
	for (int i = 0; i < LOTTERY_SIZE; i++) {
		int temp;
		//generate lottery digit
		lottery.push_back(rand() % 10);
		//input and validation
		cout << "\nEnter digit " << (i + 1) << endl;
		input = cin.get();
		cin.ignore();
		while (!ParseAndValidate(input, temp)) {
			cout << "Please enter a digit between 0 and 9." << endl;
			input = cin.get();
			cin.ignore();
		}
		guess.push_back(temp);
	}

	//array comparison
	vectorCopy = lottery;
	for (int i = 0; i < LOTTERY_SIZE; i++) {
		bool found = false;
		for (vectorIterator = vectorCopy.begin(); !found && vectorIterator != vectorCopy.end; 
				vectorIterator++) {
			if (guess[i] == *vectorIterator) {
				numCorrect++;
				vectorCopy.erase(vectorIterator);
				found = true;
			}
		}
	}

	//output
	cout << endl << setw(TITLE_WIDTH / 2) << FILL_CHAR << endl << endl;
	cout << "\nLottery numbers:" << endl;
	printIntVector(lottery);
	cout << "\nYour guess:" << endl;
	printIntVector(guess);
	if (numCorrect == LOTTERY_SIZE)
		cout << endl << "You won the lottery!" << endl;
	else
		cout << endl << numCorrect << " numbers were correct." << endl;
	

	//end
	cout << setw(TITLE_WIDTH) << FILL_CHAR << endl << endl;
	cin.get();
	cin.ignore();
	return 0;
}

//prints a centered title
void PrintTitle() {
	cout << setfill(FILL_CHAR) << setw(TITLE_WIDTH) << FILL_CHAR << endl;
	cout << setfill(' ') << setw((TITLE_WIDTH / 2) + (TITLE.length() / 2)) << TITLE << endl;
	cout << setfill(FILL_CHAR) << setw(TITLE_WIDTH) << FILL_CHAR << endl;
};
bool ParseAndValidate(int input, int &result) {
	int temp = input - '0';
	if (temp < 0 || temp > 9)
		return false;
	result = temp;
	return true;
}
void printIntVector(vector<int> intVector) {
	cout << endl;
	for (int i = 0; i < intVector.size(); i++)
		cout << ' ' << intVector[i];
	cout << endl;
}
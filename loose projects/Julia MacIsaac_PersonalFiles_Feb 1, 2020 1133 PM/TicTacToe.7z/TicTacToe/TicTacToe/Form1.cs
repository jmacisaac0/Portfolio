﻿/*
 * Julian MacIsaac
 * Tic Tac Toe
 * Hands on Test 4
 */ 

using System;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class TictactoeForm : Form
    {
        enum Player {x, o}
        int BOARD_DIMENSION = 3;
        Button[,] btnArray;

        public TictactoeForm()
        {
            InitializeComponent();
        }

        private void TictactoeForm_Load(object sender, EventArgs e)
        {
            //buttons are used instead of labels because I want to make this playable later
            //used to structure button locations in code
            btnArray = new Button[BOARD_DIMENSION, BOARD_DIMENSION];
            btnArray[0,0] = NWBtn;
            btnArray[0,1] = NBtn;
            btnArray[0,2] = NEBtn;
            btnArray[1,0] = WBtn;
            btnArray[1,1] = CenterBtn;
            btnArray[1,2] = EBtn;
            btnArray[2,0] = SWBtn;
            btnArray[2,1] = SBtn;
            btnArray[2,2] = SEBtn;
        }

        private void newGameBtn_Click(object sender, EventArgs e)
        {
            RunAutoGame();
        }

        //this is a separate method to allow for more options, like a player game, later
        private void RunAutoGame()
        {
            int[,] gameBoard = GenerateRandomBoard();
            //IsWinner finds the winner of the passed player on the passewd board and returns a boolean value, which
            //is used to by the DisplayWinner method.
            DisplayWinner(IsWinner(gameBoard, (int)Player.x), IsWinner(gameBoard, (int)Player.o));
        }

        private int[,] GenerateRandomBoard()
        {
            Random r = new Random();
            //parallel to array of buttons
            int[,] newBoard = new int[BOARD_DIMENSION, BOARD_DIMENSION];

            //value of 0 or 1 is placed in each element, which correspond to x and o, respectively
            int temp;
            for (int i = 0; i < BOARD_DIMENSION; i++)
            {
                for (int j = 0; j < BOARD_DIMENSION; j++)
                {
                    temp = r.Next(2);
                    newBoard[i,j] = temp;
                    //updates the corresponding button to display x or o
                    RefreshBtn(i, j, temp);
                }
            }
            return newBoard;
        }

        //x and y are flipped to match array size declarators 
        private void RefreshBtn(int y, int x, int binNum)
        {
            //if 0, the button at the passed coordinates will display x, else it will display o
            if (binNum == (int)Player.x) { btnArray[y, x].Text = "X"; }
            else if (binNum == (int)Player.o) { btnArray[y, x].Text = "O"; }
            else
            {
                MessageBox.Show("There was a logical error in method RefreshBtn",
                                   "Error", 
                                   MessageBoxButtons.OK, 
                                   MessageBoxIcon.Error);
            }
        }

        private bool IsWinner(int[,] inArray, int player)
        {
            bool win = false;

            /*
             * starts from center sqaure, checking all possible wins using the center.
             * then checks top left and bottom right corners to find the other possible wins
             * All wins must go through one or more of these squares
             */ 
            if (inArray[1,1] == player)
            {
                if (inArray[0,1] == player && inArray[2, 1] == player) { win = true; }
                else if (inArray[0,0] == player && inArray[2,2] == player) { win = true; }
                else if (inArray[1,0] == player && inArray[1,2] == player) { win = true; }
                else if (inArray[2,0] == player && inArray[0,2] == player) { win = true; }
            }
            if (!win && inArray[0,0] == player)
            {
                if (inArray[0,1] == player && inArray[0,2] == player) { win = true; }
                else if (inArray[1,0] == player && inArray[2,0] == player) { win = true; }
            }
            if (!win && inArray[2,2] == player)
            {
                if (inArray[2,0] == player && inArray[2,1] == player) { win = true; }
                else if (inArray[0,2] == player && inArray[1,2] == player) { win = true; }
            }
            return win;
        }

        private void DisplayWinner(bool xWin, bool oWin)
        {
            if (xWin == true && oWin == true) {
                MessageBox.Show("The game was a draw.", "Draw", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (xWin == true)
            {
                MessageBox.Show("X wins!", "X win", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else if (oWin == true)
            {
                MessageBox.Show("O wins!", "O win", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                MessageBox.Show("Neither player won", "Draw", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }

        }
    }
}

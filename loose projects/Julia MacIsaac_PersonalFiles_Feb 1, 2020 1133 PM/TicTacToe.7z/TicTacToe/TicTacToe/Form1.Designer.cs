﻿namespace TicTacToe
{
    partial class TictactoeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NWBtn = new System.Windows.Forms.Button();
            this.EBtn = new System.Windows.Forms.Button();
            this.SBtn = new System.Windows.Forms.Button();
            this.SWBtn = new System.Windows.Forms.Button();
            this.SEBtn = new System.Windows.Forms.Button();
            this.CenterBtn = new System.Windows.Forms.Button();
            this.WBtn = new System.Windows.Forms.Button();
            this.NEBtn = new System.Windows.Forms.Button();
            this.NBtn = new System.Windows.Forms.Button();
            this.newGameBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // NWBtn
            // 
            this.NWBtn.BackColor = System.Drawing.Color.Black;
            this.NWBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NWBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.NWBtn.FlatAppearance.BorderSize = 10;
            this.NWBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.NWBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NWBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.NWBtn.ForeColor = System.Drawing.Color.White;
            this.NWBtn.Location = new System.Drawing.Point(12, 12);
            this.NWBtn.Name = "NWBtn";
            this.NWBtn.Size = new System.Drawing.Size(150, 150);
            this.NWBtn.TabIndex = 0;
            this.NWBtn.UseVisualStyleBackColor = false;
            // 
            // EBtn
            // 
            this.EBtn.BackColor = System.Drawing.Color.Black;
            this.EBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.EBtn.FlatAppearance.BorderSize = 10;
            this.EBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.EBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.EBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.EBtn.ForeColor = System.Drawing.Color.White;
            this.EBtn.Location = new System.Drawing.Point(324, 168);
            this.EBtn.Name = "EBtn";
            this.EBtn.Size = new System.Drawing.Size(150, 150);
            this.EBtn.TabIndex = 1;
            this.EBtn.UseVisualStyleBackColor = false;
            // 
            // SBtn
            // 
            this.SBtn.BackColor = System.Drawing.Color.Black;
            this.SBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.SBtn.FlatAppearance.BorderSize = 10;
            this.SBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.SBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.SBtn.ForeColor = System.Drawing.Color.White;
            this.SBtn.Location = new System.Drawing.Point(168, 324);
            this.SBtn.Name = "SBtn";
            this.SBtn.Size = new System.Drawing.Size(150, 150);
            this.SBtn.TabIndex = 2;
            this.SBtn.UseVisualStyleBackColor = false;
            // 
            // SWBtn
            // 
            this.SWBtn.BackColor = System.Drawing.Color.Black;
            this.SWBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SWBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.SWBtn.FlatAppearance.BorderSize = 10;
            this.SWBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.SWBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SWBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.SWBtn.ForeColor = System.Drawing.Color.White;
            this.SWBtn.Location = new System.Drawing.Point(12, 324);
            this.SWBtn.Name = "SWBtn";
            this.SWBtn.Size = new System.Drawing.Size(150, 150);
            this.SWBtn.TabIndex = 3;
            this.SWBtn.UseVisualStyleBackColor = false;
            // 
            // SEBtn
            // 
            this.SEBtn.BackColor = System.Drawing.Color.Black;
            this.SEBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SEBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.SEBtn.FlatAppearance.BorderSize = 10;
            this.SEBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.SEBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SEBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.SEBtn.ForeColor = System.Drawing.Color.White;
            this.SEBtn.Location = new System.Drawing.Point(324, 324);
            this.SEBtn.Name = "SEBtn";
            this.SEBtn.Size = new System.Drawing.Size(150, 150);
            this.SEBtn.TabIndex = 4;
            this.SEBtn.UseVisualStyleBackColor = false;
            // 
            // CenterBtn
            // 
            this.CenterBtn.BackColor = System.Drawing.Color.Black;
            this.CenterBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CenterBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.CenterBtn.FlatAppearance.BorderSize = 10;
            this.CenterBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.CenterBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CenterBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.CenterBtn.ForeColor = System.Drawing.Color.White;
            this.CenterBtn.Location = new System.Drawing.Point(168, 168);
            this.CenterBtn.Name = "CenterBtn";
            this.CenterBtn.Size = new System.Drawing.Size(150, 150);
            this.CenterBtn.TabIndex = 5;
            this.CenterBtn.UseVisualStyleBackColor = false;
            // 
            // WBtn
            // 
            this.WBtn.BackColor = System.Drawing.Color.Black;
            this.WBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.WBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.WBtn.FlatAppearance.BorderSize = 10;
            this.WBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.WBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.WBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.WBtn.ForeColor = System.Drawing.Color.White;
            this.WBtn.Location = new System.Drawing.Point(12, 168);
            this.WBtn.Name = "WBtn";
            this.WBtn.Size = new System.Drawing.Size(150, 150);
            this.WBtn.TabIndex = 6;
            this.WBtn.UseVisualStyleBackColor = false;
            // 
            // NEBtn
            // 
            this.NEBtn.BackColor = System.Drawing.Color.Black;
            this.NEBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NEBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.NEBtn.FlatAppearance.BorderSize = 10;
            this.NEBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.NEBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NEBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.NEBtn.ForeColor = System.Drawing.Color.White;
            this.NEBtn.Location = new System.Drawing.Point(324, 12);
            this.NEBtn.Name = "NEBtn";
            this.NEBtn.Size = new System.Drawing.Size(150, 150);
            this.NEBtn.TabIndex = 7;
            this.NEBtn.UseVisualStyleBackColor = false;
            // 
            // NBtn
            // 
            this.NBtn.BackColor = System.Drawing.Color.Black;
            this.NBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.NBtn.FlatAppearance.BorderSize = 10;
            this.NBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.NBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NBtn.Font = new System.Drawing.Font("Maiandra GD", 72F);
            this.NBtn.ForeColor = System.Drawing.Color.White;
            this.NBtn.Location = new System.Drawing.Point(168, 12);
            this.NBtn.Name = "NBtn";
            this.NBtn.Size = new System.Drawing.Size(150, 150);
            this.NBtn.TabIndex = 8;
            this.NBtn.UseVisualStyleBackColor = false;
            // 
            // newGameBtn
            // 
            this.newGameBtn.AutoEllipsis = true;
            this.newGameBtn.BackColor = System.Drawing.Color.Black;
            this.newGameBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.newGameBtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.newGameBtn.FlatAppearance.BorderSize = 10;
            this.newGameBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.newGameBtn.Font = new System.Drawing.Font("Rockwell Extra Bold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newGameBtn.ForeColor = System.Drawing.Color.White;
            this.newGameBtn.Location = new System.Drawing.Point(12, 480);
            this.newGameBtn.Name = "newGameBtn";
            this.newGameBtn.Size = new System.Drawing.Size(462, 34);
            this.newGameBtn.TabIndex = 9;
            this.newGameBtn.Text = "New Game";
            this.newGameBtn.UseVisualStyleBackColor = false;
            this.newGameBtn.Click += new System.EventHandler(this.newGameBtn_Click);
            // 
            // TictactoeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(484, 522);
            this.Controls.Add(this.newGameBtn);
            this.Controls.Add(this.NBtn);
            this.Controls.Add(this.NEBtn);
            this.Controls.Add(this.WBtn);
            this.Controls.Add(this.CenterBtn);
            this.Controls.Add(this.SEBtn);
            this.Controls.Add(this.SWBtn);
            this.Controls.Add(this.SBtn);
            this.Controls.Add(this.EBtn);
            this.Controls.Add(this.NWBtn);
            this.Name = "TictactoeForm";
            this.Text = "Tic Tac Toe";
            this.Load += new System.EventHandler(this.TictactoeForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button NWBtn;
        private System.Windows.Forms.Button EBtn;
        private System.Windows.Forms.Button SBtn;
        private System.Windows.Forms.Button SWBtn;
        private System.Windows.Forms.Button SEBtn;
        private System.Windows.Forms.Button CenterBtn;
        private System.Windows.Forms.Button WBtn;
        private System.Windows.Forms.Button NEBtn;
        private System.Windows.Forms.Button NBtn;
        private System.Windows.Forms.Button newGameBtn;
    }
}


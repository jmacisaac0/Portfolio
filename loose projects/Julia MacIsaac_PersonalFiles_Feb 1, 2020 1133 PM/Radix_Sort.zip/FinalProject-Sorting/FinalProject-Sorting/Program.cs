﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject_Sorting
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declared 3 arrays for sorting, with size 500000
            const int SIZE = 500000;
            Random rand = new Random();
            int[] arr = new int[SIZE];
            int[] arr2 = new int[SIZE];
            int[] arr3 = new int[SIZE];

            //Three arrays are created for the criteria required
            for (int i = 0; i < SIZE; i++)
            {
                arr[i] = i + 1;
            }

            for (int i = 0; i < SIZE; i++)
            {
                arr2[i] = SIZE - i;
            }

            for (int i = 0; i < SIZE; i++)
            {
                arr3[i] = rand.Next(1, 500000);
            }

            //Instance of the RadixSort class created
            RadixSort rs = new RadixSort(); 

            /*
             * For each sort (sort Ascending, Descending, and Random in ascending order), the current time is taken and added to a DateTime variable.
             * This variable is used to track the time taken to complete the radix sort on each array. A message is displayed on the console for each result (which
             * is DateTime.Now minus the variable created for each sort.
             */ 
            DateTime timeAsc = DateTime.Now;
            rs.RadixSortAsc(arr);
            string result = ("Radix Sort Asc total time: " + (DateTime.Now - timeAsc));
            Console.WriteLine(result);

            
            DateTime timeDesc = DateTime.Now;
            rs.RadixSortAsc(arr2);
            string result2 = ("Radix Sort Desc total time: " + (DateTime.Now - timeDesc));
            Console.WriteLine(result2);


            DateTime timeRandom = DateTime.Now;
            rs.RadixSortAsc(arr3);
            string result3 = ("Radix Sort Random total time: " + (DateTime.Now - timeRandom));
            Console.WriteLine(result3);

            Console.WriteLine();
            Console.ReadKey();
        }
    }
}

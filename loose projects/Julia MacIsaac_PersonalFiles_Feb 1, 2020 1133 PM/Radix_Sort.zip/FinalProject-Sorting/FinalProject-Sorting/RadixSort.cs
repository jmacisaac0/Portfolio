﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProject_Sorting
{
    class RadixSort
    {
        /*
         * Starts at significant bit. Take all that start with 0 on one side and 1 on the other. One with all 0s moves to left, all 1s to right.
         */ 
        public void RadixSortAsc(int[] arr)
        {
            //uses bitshift operator
            int i, j;
            int[] temp = new int[arr.Length];
            /*
             * The initial shift value is 31. The 31 refers to bits. There are actually 32 bits in a integer but the bit numbering start at 0 so 0-31. 31 is the signed bit.
             * For each iteration, the shift is decremented before use, and the condition is checked that shift is greater than -1.
             */ 
            for (int shift = 31; shift > -1; --shift)
            {
                //j is the index of temp
                j = 0;
                for (i = 0; i < arr.Length; ++i)
                {
                    /*
                     * Move is true when the number resulting from arr[i] << shift is greater than or equal to 0.
                     * It is negative if the left-most bit is 1. That is the signed bit.
                     */ 
                    bool move = (arr[i] << shift) >= 0;

                    /*
                     * This line only does something if shift is equal to 0.
                     * If shift equals 0, then the numbers are based on their real sign.
                     */
                    if (shift == 0 ? !move : move)
                        //if 0
                        //The arr[i] value is placed in arr[i - j].
                        arr[i - j] = arr[i];
                    else
                        //if 1
                        //The temp array is the sorted array
                        temp[j++] = arr[i];

                    //Alternative to ternary operator, slower
                    /*if (shift == 0)
                    {
                        move = !move;
                    }
                    if (move)
                    {
                        arr[i - j] = arr[i];
                    }
                    else
                    {
                        temp[j++] = arr[i];
                    }*/
                }

                //temp array is copied to the arr array
                Array.Copy(temp, 0, arr, arr.Length - j, j);
            }
        }
    }
}


package bordermenu;

public class BorderMenu {

    public static void main(String[] args) {
        
        BorderMenuGUI x = new BorderMenuGUI();
        x.setVisible(true);
        
    }
    
}

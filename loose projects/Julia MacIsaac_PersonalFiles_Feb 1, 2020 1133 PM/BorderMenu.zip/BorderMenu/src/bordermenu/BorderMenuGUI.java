
package bordermenu;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class BorderMenuGUI extends JFrame implements ActionListener {
    
    JLabel borderDisplayLabel;
    JMenuBar menuBar;
    JMenu menu, submenu1, submenu2;
    JMenuItem menuItem;
    
    Container contentPane;
    
    public BorderMenuGUI() {
        
        setSize(200,100);
        setTitle("Border Menu");
        
        contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        
        menuBar = new JMenuBar();
        
        menu = new JMenu("Border Options");  
        
        submenu1 = new JMenu("Beveled");
        
        submenu2 = new JMenu("Raised");        
        menuItem = new JMenuItem("Black");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("BeveledRaisedBlack");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Red");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("BeveledRaisedRed");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Blue");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("BeveledRaisedBlue");
        submenu2.add(menuItem);
        submenu1.add(submenu2);
        
        submenu2 = new JMenu("Lowered");
        menuItem = new JMenuItem("Black");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("BeveledLoweredBlack");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Red");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("BeveledLoweredRed");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Blue");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("BeveledLoweredBlue");
        submenu2.add(menuItem);
        submenu1.add(submenu2);
        
        menu.add(submenu1);
        submenu1 = new JMenu("Etched");
        
        submenu2 = new JMenu("Raised");        
        menuItem = new JMenuItem("Black");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("EtchedRaisedBlack");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Red");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("EtchedRaisedRed");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Blue");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("EtchedRaisedBlue");
        submenu2.add(menuItem);
        submenu1.add(submenu2);
        
        submenu2 = new JMenu("Lowered");
        menuItem = new JMenuItem("Black");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("EtchedLoweredBlack");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Red");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("EtchedLoweredRed");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Blue");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("EtchedLoweredBlue");
        submenu2.add(menuItem);
        submenu1.add(submenu2);
        
        menu.add(submenu1);
        submenu1 = new JMenu("Line");
        
        submenu2 = new JMenu("Small");
        menuItem = new JMenuItem("Black");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("LineSmallBlack");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Red");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("LineSmallRed");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Blue");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("LineSmallBlue");
        submenu2.add(menuItem);
        submenu1.add(submenu2);
        
        submenu2 = new JMenu("Medium");
        menuItem = new JMenuItem("Black");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("LineMediumBlack");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Red");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("LineMediumRed");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Blue");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("LineMediumBlue");
        submenu2.add(menuItem);
        submenu1.add(submenu2);
        
        submenu2 = new JMenu("Large");
        menuItem = new JMenuItem("Black");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("LineMediumBlack");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Red");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("LineMediumRed");
        submenu2.add(menuItem);
        menuItem = new JMenuItem("Blue");
        menuItem.addActionListener(this);
        menuItem.setActionCommand("LineMediumBlue");
        submenu2.add(menuItem);
        submenu1.add(submenu2);
        
        menu.add(submenu1);
        menuBar.add(menu);
        contentPane.add(menuBar);
        
        borderDisplayLabel = new JLabel("");
        contentPane.add(borderDisplayLabel, BorderLayout.EAST);
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    public void actionPerformed(ActionEvent e) {
        
        String actionCommand = e.getActionCommand();
        Border newBorder;
        
        if (actionCommand.contains("Beveled") ||
            actionCommand.contains("Etched")) {
            
            if (actionCommand.contains("Beveled")) {
                BorderFactory.createEtchedBorder()
            }
            else {
                
            }
            
            if (actionCommand.contains("Raised")) {
                
            }
            else if (actionCommand.contains("Lowered")) {
                
            }
            else {
                System.out.println("ERROR");
            }
        }
        else if (actionCommand.contains("Line")) {
            
            if (actionCommand.contains("Small")) {
                
            }
            else if (actionCommand.contains("Medium")) {
                
            }
            else if (actionCommand.contains("Large")) {
                
            }
        }
        else {
            System.out.println("ERROR");
        }
        
        if (actionCommand.contains("Black")) {
            
        }
        else if (actionCommand.contains("Red")) {
            
        }
        else if (actionCommand.contains("Blue")) {
            
        }
        else {
            System.out.println("ERROR");
        }
    }
}

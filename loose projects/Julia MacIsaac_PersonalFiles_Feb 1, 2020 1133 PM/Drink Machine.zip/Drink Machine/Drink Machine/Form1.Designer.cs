﻿namespace Drink_Machine
{
    partial class drinkMachineForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ColaGrpbox = new System.Windows.Forms.GroupBox();
            this.ColaLbl = new System.Windows.Forms.Label();
            this.ColaPicbox = new System.Windows.Forms.PictureBox();
            this.ColaTxtbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.RootbeerGrpbox = new System.Windows.Forms.GroupBox();
            this.RootbeerLbl = new System.Windows.Forms.Label();
            this.RootbeerPicbox = new System.Windows.Forms.PictureBox();
            this.RootbeerTxtbox = new System.Windows.Forms.TextBox();
            this.LemonlimeGrpbox = new System.Windows.Forms.GroupBox();
            this.LemonlimeLbl = new System.Windows.Forms.Label();
            this.LemonlimePicbox = new System.Windows.Forms.PictureBox();
            this.LemonlimeTxtbox = new System.Windows.Forms.TextBox();
            this.GrapeGrpbox = new System.Windows.Forms.GroupBox();
            this.GrapeLbl = new System.Windows.Forms.Label();
            this.GrapePicbox = new System.Windows.Forms.PictureBox();
            this.GrapeTxtbox = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.CreamLbl = new System.Windows.Forms.Label();
            this.CreamPicbox = new System.Windows.Forms.PictureBox();
            this.CreamTxtbox = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.SalesLbl = new System.Windows.Forms.Label();
            this.SalesTxtbox = new System.Windows.Forms.TextBox();
            this.ColaGrpbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColaPicbox)).BeginInit();
            this.RootbeerGrpbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RootbeerPicbox)).BeginInit();
            this.LemonlimeGrpbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LemonlimePicbox)).BeginInit();
            this.GrapeGrpbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GrapePicbox)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CreamPicbox)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // ColaGrpbox
            // 
            this.ColaGrpbox.Controls.Add(this.ColaLbl);
            this.ColaGrpbox.Controls.Add(this.ColaPicbox);
            this.ColaGrpbox.Controls.Add(this.ColaTxtbox);
            this.ColaGrpbox.Location = new System.Drawing.Point(12, 37);
            this.ColaGrpbox.Name = "ColaGrpbox";
            this.ColaGrpbox.Size = new System.Drawing.Size(160, 92);
            this.ColaGrpbox.TabIndex = 0;
            this.ColaGrpbox.TabStop = false;
            // 
            // ColaLbl
            // 
            this.ColaLbl.AutoSize = true;
            this.ColaLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ColaLbl.Location = new System.Drawing.Point(85, 19);
            this.ColaLbl.Name = "ColaLbl";
            this.ColaLbl.Size = new System.Drawing.Size(54, 20);
            this.ColaLbl.TabIndex = 16;
            this.ColaLbl.Text = "$1.00";
            // 
            // ColaPicbox
            // 
            this.ColaPicbox.Image = global::Drink_Machine.Properties.Resources.Cola;
            this.ColaPicbox.Location = new System.Drawing.Point(6, 19);
            this.ColaPicbox.Name = "ColaPicbox";
            this.ColaPicbox.Size = new System.Drawing.Size(62, 62);
            this.ColaPicbox.TabIndex = 6;
            this.ColaPicbox.TabStop = false;
            this.ColaPicbox.Click += new System.EventHandler(this.ColaPicbox_Click);
            // 
            // ColaTxtbox
            // 
            this.ColaTxtbox.Location = new System.Drawing.Point(74, 61);
            this.ColaTxtbox.Name = "ColaTxtbox";
            this.ColaTxtbox.ReadOnly = true;
            this.ColaTxtbox.Size = new System.Drawing.Size(77, 20);
            this.ColaTxtbox.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(96, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select a Drink";
            // 
            // ExitBtn
            // 
            this.ExitBtn.Location = new System.Drawing.Point(12, 331);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(326, 23);
            this.ExitBtn.TabIndex = 9;
            this.ExitBtn.Text = "Exit";
            this.ExitBtn.UseVisualStyleBackColor = true;
            // 
            // RootbeerGrpbox
            // 
            this.RootbeerGrpbox.Controls.Add(this.RootbeerLbl);
            this.RootbeerGrpbox.Controls.Add(this.RootbeerPicbox);
            this.RootbeerGrpbox.Controls.Add(this.RootbeerTxtbox);
            this.RootbeerGrpbox.Location = new System.Drawing.Point(178, 37);
            this.RootbeerGrpbox.Name = "RootbeerGrpbox";
            this.RootbeerGrpbox.Size = new System.Drawing.Size(160, 92);
            this.RootbeerGrpbox.TabIndex = 10;
            this.RootbeerGrpbox.TabStop = false;
            // 
            // RootbeerLbl
            // 
            this.RootbeerLbl.AutoSize = true;
            this.RootbeerLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.RootbeerLbl.Location = new System.Drawing.Point(86, 19);
            this.RootbeerLbl.Name = "RootbeerLbl";
            this.RootbeerLbl.Size = new System.Drawing.Size(54, 20);
            this.RootbeerLbl.TabIndex = 16;
            this.RootbeerLbl.Text = "$1.00";
            // 
            // RootbeerPicbox
            // 
            this.RootbeerPicbox.Image = global::Drink_Machine.Properties.Resources.RootBeer;
            this.RootbeerPicbox.Location = new System.Drawing.Point(6, 19);
            this.RootbeerPicbox.Name = "RootbeerPicbox";
            this.RootbeerPicbox.Size = new System.Drawing.Size(62, 62);
            this.RootbeerPicbox.TabIndex = 6;
            this.RootbeerPicbox.TabStop = false;
            this.RootbeerPicbox.Click += new System.EventHandler(this.RootbeerPicbox_Click);
            // 
            // RootbeerTxtbox
            // 
            this.RootbeerTxtbox.Location = new System.Drawing.Point(74, 61);
            this.RootbeerTxtbox.Name = "RootbeerTxtbox";
            this.RootbeerTxtbox.ReadOnly = true;
            this.RootbeerTxtbox.Size = new System.Drawing.Size(77, 20);
            this.RootbeerTxtbox.TabIndex = 5;
            // 
            // LemonlimeGrpbox
            // 
            this.LemonlimeGrpbox.Controls.Add(this.LemonlimeLbl);
            this.LemonlimeGrpbox.Controls.Add(this.LemonlimePicbox);
            this.LemonlimeGrpbox.Controls.Add(this.LemonlimeTxtbox);
            this.LemonlimeGrpbox.Location = new System.Drawing.Point(12, 135);
            this.LemonlimeGrpbox.Name = "LemonlimeGrpbox";
            this.LemonlimeGrpbox.Size = new System.Drawing.Size(160, 92);
            this.LemonlimeGrpbox.TabIndex = 11;
            this.LemonlimeGrpbox.TabStop = false;
            // 
            // LemonlimeLbl
            // 
            this.LemonlimeLbl.AutoSize = true;
            this.LemonlimeLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LemonlimeLbl.Location = new System.Drawing.Point(85, 19);
            this.LemonlimeLbl.Name = "LemonlimeLbl";
            this.LemonlimeLbl.Size = new System.Drawing.Size(54, 20);
            this.LemonlimeLbl.TabIndex = 16;
            this.LemonlimeLbl.Text = "$1.00";
            // 
            // LemonlimePicbox
            // 
            this.LemonlimePicbox.Image = global::Drink_Machine.Properties.Resources.LemonLime;
            this.LemonlimePicbox.Location = new System.Drawing.Point(6, 19);
            this.LemonlimePicbox.Name = "LemonlimePicbox";
            this.LemonlimePicbox.Size = new System.Drawing.Size(62, 62);
            this.LemonlimePicbox.TabIndex = 6;
            this.LemonlimePicbox.TabStop = false;
            this.LemonlimePicbox.Click += new System.EventHandler(this.LemonlimePicbox_Click);
            // 
            // LemonlimeTxtbox
            // 
            this.LemonlimeTxtbox.Location = new System.Drawing.Point(74, 61);
            this.LemonlimeTxtbox.Name = "LemonlimeTxtbox";
            this.LemonlimeTxtbox.ReadOnly = true;
            this.LemonlimeTxtbox.Size = new System.Drawing.Size(77, 20);
            this.LemonlimeTxtbox.TabIndex = 5;
            // 
            // GrapeGrpbox
            // 
            this.GrapeGrpbox.Controls.Add(this.GrapeLbl);
            this.GrapeGrpbox.Controls.Add(this.GrapePicbox);
            this.GrapeGrpbox.Controls.Add(this.GrapeTxtbox);
            this.GrapeGrpbox.Location = new System.Drawing.Point(178, 135);
            this.GrapeGrpbox.Name = "GrapeGrpbox";
            this.GrapeGrpbox.Size = new System.Drawing.Size(160, 92);
            this.GrapeGrpbox.TabIndex = 12;
            this.GrapeGrpbox.TabStop = false;
            // 
            // GrapeLbl
            // 
            this.GrapeLbl.AutoSize = true;
            this.GrapeLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.GrapeLbl.Location = new System.Drawing.Point(86, 19);
            this.GrapeLbl.Name = "GrapeLbl";
            this.GrapeLbl.Size = new System.Drawing.Size(54, 20);
            this.GrapeLbl.TabIndex = 16;
            this.GrapeLbl.Text = "$1.50";
            // 
            // GrapePicbox
            // 
            this.GrapePicbox.Image = global::Drink_Machine.Properties.Resources.GrapeSoda;
            this.GrapePicbox.Location = new System.Drawing.Point(6, 19);
            this.GrapePicbox.Name = "GrapePicbox";
            this.GrapePicbox.Size = new System.Drawing.Size(62, 62);
            this.GrapePicbox.TabIndex = 6;
            this.GrapePicbox.TabStop = false;
            this.GrapePicbox.Click += new System.EventHandler(this.GrapePicbox_Click);
            // 
            // GrapeTxtbox
            // 
            this.GrapeTxtbox.Location = new System.Drawing.Point(74, 61);
            this.GrapeTxtbox.Name = "GrapeTxtbox";
            this.GrapeTxtbox.ReadOnly = true;
            this.GrapeTxtbox.Size = new System.Drawing.Size(77, 20);
            this.GrapeTxtbox.TabIndex = 5;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.CreamLbl);
            this.groupBox5.Controls.Add(this.CreamPicbox);
            this.groupBox5.Controls.Add(this.CreamTxtbox);
            this.groupBox5.Location = new System.Drawing.Point(12, 233);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(160, 92);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            // 
            // CreamLbl
            // 
            this.CreamLbl.AutoSize = true;
            this.CreamLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.CreamLbl.Location = new System.Drawing.Point(85, 19);
            this.CreamLbl.Name = "CreamLbl";
            this.CreamLbl.Size = new System.Drawing.Size(54, 20);
            this.CreamLbl.TabIndex = 16;
            this.CreamLbl.Text = "$1.50";
            // 
            // CreamPicbox
            // 
            this.CreamPicbox.Image = global::Drink_Machine.Properties.Resources.CreamSoda;
            this.CreamPicbox.Location = new System.Drawing.Point(6, 19);
            this.CreamPicbox.Name = "CreamPicbox";
            this.CreamPicbox.Size = new System.Drawing.Size(62, 62);
            this.CreamPicbox.TabIndex = 6;
            this.CreamPicbox.TabStop = false;
            this.CreamPicbox.Click += new System.EventHandler(this.CreamPicbox_Click);
            // 
            // CreamTxtbox
            // 
            this.CreamTxtbox.Location = new System.Drawing.Point(74, 61);
            this.CreamTxtbox.Name = "CreamTxtbox";
            this.CreamTxtbox.ReadOnly = true;
            this.CreamTxtbox.Size = new System.Drawing.Size(77, 20);
            this.CreamTxtbox.TabIndex = 5;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.SalesLbl);
            this.groupBox6.Controls.Add(this.SalesTxtbox);
            this.groupBox6.Location = new System.Drawing.Point(178, 233);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(160, 92);
            this.groupBox6.TabIndex = 14;
            this.groupBox6.TabStop = false;
            // 
            // SalesLbl
            // 
            this.SalesLbl.AutoSize = true;
            this.SalesLbl.Location = new System.Drawing.Point(45, 31);
            this.SalesLbl.Name = "SalesLbl";
            this.SalesLbl.Size = new System.Drawing.Size(63, 13);
            this.SalesLbl.TabIndex = 15;
            this.SalesLbl.Text = "Total Sales:";
            // 
            // SalesTxtbox
            // 
            this.SalesTxtbox.Location = new System.Drawing.Point(40, 47);
            this.SalesTxtbox.Name = "SalesTxtbox";
            this.SalesTxtbox.ReadOnly = true;
            this.SalesTxtbox.Size = new System.Drawing.Size(77, 20);
            this.SalesTxtbox.TabIndex = 5;
            // 
            // drinkMachineForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 359);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.GrapeGrpbox);
            this.Controls.Add(this.LemonlimeGrpbox);
            this.Controls.Add(this.RootbeerGrpbox);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ColaGrpbox);
            this.Name = "drinkMachineForm";
            this.Text = "Drink Machine";
            this.Load += new System.EventHandler(this.drinkMachineForm_Load);
            this.ColaGrpbox.ResumeLayout(false);
            this.ColaGrpbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ColaPicbox)).EndInit();
            this.RootbeerGrpbox.ResumeLayout(false);
            this.RootbeerGrpbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RootbeerPicbox)).EndInit();
            this.LemonlimeGrpbox.ResumeLayout(false);
            this.LemonlimeGrpbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LemonlimePicbox)).EndInit();
            this.GrapeGrpbox.ResumeLayout(false);
            this.GrapeGrpbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GrapePicbox)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CreamPicbox)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox ColaGrpbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox ColaPicbox;
        private System.Windows.Forms.TextBox ColaTxtbox;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.GroupBox RootbeerGrpbox;
        private System.Windows.Forms.PictureBox RootbeerPicbox;
        private System.Windows.Forms.TextBox RootbeerTxtbox;
        private System.Windows.Forms.GroupBox LemonlimeGrpbox;
        private System.Windows.Forms.PictureBox LemonlimePicbox;
        private System.Windows.Forms.TextBox LemonlimeTxtbox;
        private System.Windows.Forms.GroupBox GrapeGrpbox;
        private System.Windows.Forms.PictureBox GrapePicbox;
        private System.Windows.Forms.TextBox GrapeTxtbox;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.PictureBox CreamPicbox;
        private System.Windows.Forms.TextBox CreamTxtbox;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label SalesLbl;
        private System.Windows.Forms.TextBox SalesTxtbox;
        private System.Windows.Forms.Label ColaLbl;
        private System.Windows.Forms.Label RootbeerLbl;
        private System.Windows.Forms.Label LemonlimeLbl;
        private System.Windows.Forms.Label GrapeLbl;
        private System.Windows.Forms.Label CreamLbl;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Drink_Machine
{
    public partial class drinkMachineForm : Form
    {
        const int DRINK_MAX = 20;
        const double COLA_PRICE = 1.00;
        const double ROOTBEER_PRICE = 1.00;
        const double LEMONLIME_PRICE = 1.00;
        const double GRAPE_PRICE = 1.50;
        const double CREAM_PRICE = 1.50;
        Pop Cola = new Pop();
        Pop Rootbeer = new Pop();
        Pop Lemonlime = new Pop();
        Pop Grape = new Pop();
        Pop Cream = new Pop();

        public drinkMachineForm()
        {
            InitializeComponent();
        }

        private void drinkMachineForm_Load(object sender, EventArgs e)
        {
            ColaLbl.Text = '$' + COLA_PRICE.ToString();
        }

        private void ColaPicbox_Click(object sender, EventArgs e)
        {

        }

        private void RootbeerPicbox_Click(object sender, EventArgs e)
        {

        }

        private void LemonlimePicbox_Click(object sender, EventArgs e)
        {

        }

        private void GrapePicbox_Click(object sender, EventArgs e)
        {

        }

        private void CreamPicbox_Click(object sender, EventArgs e)
        {

        }

        struct Pop
        {
            string drinkName;
            double drinkCost;
            int drinksLeft;
        }
    }
}

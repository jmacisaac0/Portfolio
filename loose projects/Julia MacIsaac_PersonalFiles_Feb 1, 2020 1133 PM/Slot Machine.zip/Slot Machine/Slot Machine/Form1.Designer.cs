﻿namespace Slot_Machine
{
    partial class SlotMachineForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SpinBtn = new System.Windows.Forms.Button();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.InputTxtbox = new System.Windows.Forms.TextBox();
            this.FruitTxtbox2 = new System.Windows.Forms.PictureBox();
            this.FruitTxtbox3 = new System.Windows.Forms.PictureBox();
            this.FruitTxtbox1 = new System.Windows.Forms.PictureBox();
            this.WinningsLbl = new System.Windows.Forms.Label();
            this.DollarSymbolLbl1 = new System.Windows.Forms.Label();
            this.WinningsTxtbox = new System.Windows.Forms.TextBox();
            this.MessageTxtbox = new System.Windows.Forms.TextBox();
            this.DollarSymbolLbl2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.FruitTxtbox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FruitTxtbox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FruitTxtbox1)).BeginInit();
            this.SuspendLayout();
            // 
            // SpinBtn
            // 
            this.SpinBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SpinBtn.Font = new System.Drawing.Font("Niagara Engraved", 26.25F, System.Drawing.FontStyle.Bold);
            this.SpinBtn.ForeColor = System.Drawing.Color.White;
            this.SpinBtn.Location = new System.Drawing.Point(123, 328);
            this.SpinBtn.Name = "SpinBtn";
            this.SpinBtn.Size = new System.Drawing.Size(172, 44);
            this.SpinBtn.TabIndex = 11;
            this.SpinBtn.Text = "SPIN!";
            this.SpinBtn.UseVisualStyleBackColor = false;
            this.SpinBtn.Click += new System.EventHandler(this.SpinBtn_Click);
            // 
            // ExitBtn
            // 
            this.ExitBtn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ExitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitBtn.ForeColor = System.Drawing.Color.White;
            this.ExitBtn.Location = new System.Drawing.Point(146, 378);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(128, 23);
            this.ExitBtn.TabIndex = 10;
            this.ExitBtn.Text = "Exit";
            this.ExitBtn.UseVisualStyleBackColor = false;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // InputTxtbox
            // 
            this.InputTxtbox.Font = new System.Drawing.Font("Niagara Engraved", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InputTxtbox.Location = new System.Drawing.Point(123, 229);
            this.InputTxtbox.Name = "InputTxtbox";
            this.InputTxtbox.Size = new System.Drawing.Size(172, 45);
            this.InputTxtbox.TabIndex = 9;
            this.InputTxtbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FruitTxtbox2
            // 
            this.FruitTxtbox2.Image = global::Slot_Machine.Properties.Resources.Watermelon;
            this.FruitTxtbox2.Location = new System.Drawing.Point(146, 12);
            this.FruitTxtbox2.Name = "FruitTxtbox2";
            this.FruitTxtbox2.Size = new System.Drawing.Size(128, 128);
            this.FruitTxtbox2.TabIndex = 8;
            this.FruitTxtbox2.TabStop = false;
            // 
            // FruitTxtbox3
            // 
            this.FruitTxtbox3.Image = global::Slot_Machine.Properties.Resources.Watermelon;
            this.FruitTxtbox3.Location = new System.Drawing.Point(280, 12);
            this.FruitTxtbox3.Name = "FruitTxtbox3";
            this.FruitTxtbox3.Size = new System.Drawing.Size(128, 128);
            this.FruitTxtbox3.TabIndex = 7;
            this.FruitTxtbox3.TabStop = false;
            // 
            // FruitTxtbox1
            // 
            this.FruitTxtbox1.Image = global::Slot_Machine.Properties.Resources.Watermelon;
            this.FruitTxtbox1.Location = new System.Drawing.Point(12, 12);
            this.FruitTxtbox1.Name = "FruitTxtbox1";
            this.FruitTxtbox1.Size = new System.Drawing.Size(128, 128);
            this.FruitTxtbox1.TabIndex = 6;
            this.FruitTxtbox1.TabStop = false;
            // 
            // WinningsLbl
            // 
            this.WinningsLbl.AutoSize = true;
            this.WinningsLbl.Font = new System.Drawing.Font("Niagara Engraved", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WinningsLbl.ForeColor = System.Drawing.Color.White;
            this.WinningsLbl.Location = new System.Drawing.Point(10, 290);
            this.WinningsLbl.Name = "WinningsLbl";
            this.WinningsLbl.Size = new System.Drawing.Size(72, 29);
            this.WinningsLbl.TabIndex = 13;
            this.WinningsLbl.Text = "Winnings";
            this.WinningsLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DollarSymbolLbl1
            // 
            this.DollarSymbolLbl1.AutoSize = true;
            this.DollarSymbolLbl1.Font = new System.Drawing.Font("Niagara Engraved", 26.25F, System.Drawing.FontStyle.Bold);
            this.DollarSymbolLbl1.ForeColor = System.Drawing.Color.White;
            this.DollarSymbolLbl1.Location = new System.Drawing.Point(89, 232);
            this.DollarSymbolLbl1.Name = "DollarSymbolLbl1";
            this.DollarSymbolLbl1.Size = new System.Drawing.Size(28, 38);
            this.DollarSymbolLbl1.TabIndex = 14;
            this.DollarSymbolLbl1.Text = "$";
            this.DollarSymbolLbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // WinningsTxtbox
            // 
            this.WinningsTxtbox.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.WinningsTxtbox.Font = new System.Drawing.Font("Niagara Engraved", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WinningsTxtbox.ForeColor = System.Drawing.Color.White;
            this.WinningsTxtbox.Location = new System.Drawing.Point(123, 280);
            this.WinningsTxtbox.Name = "WinningsTxtbox";
            this.WinningsTxtbox.ReadOnly = true;
            this.WinningsTxtbox.Size = new System.Drawing.Size(172, 45);
            this.WinningsTxtbox.TabIndex = 15;
            this.WinningsTxtbox.Text = "0";
            this.WinningsTxtbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MessageTxtbox
            // 
            this.MessageTxtbox.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MessageTxtbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.MessageTxtbox.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.MessageTxtbox.Font = new System.Drawing.Font("Niagara Engraved", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MessageTxtbox.ForeColor = System.Drawing.Color.Cyan;
            this.MessageTxtbox.Location = new System.Drawing.Point(15, 158);
            this.MessageTxtbox.Name = "MessageTxtbox";
            this.MessageTxtbox.ReadOnly = true;
            this.MessageTxtbox.Size = new System.Drawing.Size(393, 52);
            this.MessageTxtbox.TabIndex = 17;
            this.MessageTxtbox.Text = "BET SOME MONEY, BUDDY!";
            this.MessageTxtbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DollarSymbolLbl2
            // 
            this.DollarSymbolLbl2.AutoSize = true;
            this.DollarSymbolLbl2.Font = new System.Drawing.Font("Niagara Engraved", 26.25F, System.Drawing.FontStyle.Bold);
            this.DollarSymbolLbl2.ForeColor = System.Drawing.Color.White;
            this.DollarSymbolLbl2.Location = new System.Drawing.Point(89, 283);
            this.DollarSymbolLbl2.Name = "DollarSymbolLbl2";
            this.DollarSymbolLbl2.Size = new System.Drawing.Size(28, 38);
            this.DollarSymbolLbl2.TabIndex = 18;
            this.DollarSymbolLbl2.Text = "$";
            this.DollarSymbolLbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SlotMachineForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(420, 413);
            this.Controls.Add(this.DollarSymbolLbl2);
            this.Controls.Add(this.MessageTxtbox);
            this.Controls.Add(this.WinningsTxtbox);
            this.Controls.Add(this.DollarSymbolLbl1);
            this.Controls.Add(this.WinningsLbl);
            this.Controls.Add(this.SpinBtn);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.InputTxtbox);
            this.Controls.Add(this.FruitTxtbox2);
            this.Controls.Add(this.FruitTxtbox3);
            this.Controls.Add(this.FruitTxtbox1);
            this.Name = "SlotMachineForm";
            this.Text = "Slot Machine";
            this.Load += new System.EventHandler(this.SlotMachineForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.FruitTxtbox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FruitTxtbox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FruitTxtbox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SpinBtn;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.TextBox InputTxtbox;
        private System.Windows.Forms.PictureBox FruitTxtbox2;
        private System.Windows.Forms.PictureBox FruitTxtbox3;
        private System.Windows.Forms.PictureBox FruitTxtbox1;
        private System.Windows.Forms.Label WinningsLbl;
        private System.Windows.Forms.Label DollarSymbolLbl1;
        private System.Windows.Forms.TextBox WinningsTxtbox;
        private System.Windows.Forms.TextBox MessageTxtbox;
        private System.Windows.Forms.Label DollarSymbolLbl2;
    }
}


﻿using System;
using System.Drawing;
using System.Windows.Forms;


namespace Slot_Machine
{
    public partial class SlotMachineForm : Form
    {
        //constants
        const int NUM_OF_SPINS = 14; //number of times slot machine spins before it stops
        const int SPIN_CONSTANT = 20; //base wait time each spin. The lower the number, the faster
                                      //the machine spins
        const double SPIN_DECELERATION = 0.4; //must be between 0 and 1. Higher number results in 
                                              //increased deceleration
        const int NUM_OF_IMAGES = 10; //make sure added images are added to fruits array on form load


        //class variables
        Image[] fruits = new Image[NUM_OF_IMAGES];
        int totalWinnings = 0;
        int currentWinnings = 0;
        int moneySpent = 0;

        public SlotMachineForm()
        {
            InitializeComponent();
        }
        private void SlotMachineForm_Load(object sender, EventArgs e)
        {
            //assigns images to an array value so they can be changed easily
            fruits[0] = Properties.Resources.Apple;
            fruits[1] = Properties.Resources.Banana;
            fruits[2] = Properties.Resources.Cherries;
            fruits[3] = Properties.Resources.Grapes;
            fruits[4] = Properties.Resources.Lemon;
            fruits[5] = Properties.Resources.Lime;
            fruits[6] = Properties.Resources.Orange;
            fruits[7] = Properties.Resources.Pear;
            fruits[8] = Properties.Resources.Strawberry;
            fruits[9] = Properties.Resources.Watermelon;

            RandomRefresh();
        }
        private void SpinBtn_Click(object sender, EventArgs e)
        {
            //validates input, and if validated, return converted value though
            //out variable
            if (InputTxtbox.Text == "") { MessageTxtbox.Text = "YOU GOTTA BET SOMETHING!"; }
            else if (Validate(InputTxtbox.Text, out int bet)) 
            {
                Random r = new Random();
                int slot1 = r.Next(NUM_OF_IMAGES);
                int slot2 = r.Next(NUM_OF_IMAGES);
                int slot3 = r.Next(NUM_OF_IMAGES);

                //updates form
                SpinAnimation(slot1, slot2, slot3);
                InputTxtbox.Clear();

                //determines how many numbers match and takes the appropriate actions
                moneySpent += bet;
                if (slot1 == slot2 && slot1 == slot3)
                {
                    MessageTxtbox.Text = "OH BABY A TRIPLE!";
                    totalWinnings += (bet * 3);
                    currentWinnings += (bet * 3);
                    WinningsTxtbox.Text = (currentWinnings.ToString());
                }
                else if (slot1 == slot2 || slot1 == slot3 || slot2 == slot3)
                {
                    MessageTxtbox.Text = "YOU WON DOUBLE! WHAT SKILL!";
                    totalWinnings += (bet * 2);
                    currentWinnings += (bet * 2);
                    WinningsTxtbox.Text = (currentWinnings.ToString());
                }
                else
                {
                    MessageTxtbox.Text = "YOU WON NOTHING!";
                }
            } 
        }

        private void SpinAnimation(int final1, int final2, int final3)
        {
            Random r = new Random();
            int waitTime = SPIN_CONSTANT; //in milliseconds
            int timeAdd = SPIN_CONSTANT;
            MessageTxtbox.Visible = false;

            for (int i = 0; i < NUM_OF_SPINS; i++)
            {
                RandomRefresh();
                System.Threading.Thread.Sleep(waitTime);
                waitTime += timeAdd;
                timeAdd += (int)(SPIN_CONSTANT * SPIN_DECELERATION);
            }


            PicboxRefresh(final1, final2, final3);
            System.Threading.Thread.Sleep(2000);
            MessageTxtbox.Visible = true;
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            //changes the wording of the messagebox based on whether the user won or lost money
            if (moneySpent > totalWinnings)
            {
                MessageBox.Show("You bet $" + moneySpent + 
                                "\nYou won $" + totalWinnings +
                                "\nYou lost $" + (moneySpent - totalWinnings),
                                "Results", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (totalWinnings >= moneySpent) {
                MessageBox.Show("You bet $" + moneySpent +
                                "\nYou won $" + totalWinnings +
                                "\nYou gained $" + (totalWinnings - moneySpent),
                                "Results", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            Application.Exit();
        }

        private void PicboxRefresh()
        {
            FruitTxtbox1.Refresh();
            FruitTxtbox2.Refresh();
            FruitTxtbox3.Refresh();
        }
        private void PicboxRefresh(int val, int selection)
        {
            switch (selection) {
                case 1:
                    FruitTxtbox1.Image = fruits[val];
                    FruitTxtbox1.Refresh();
                    break;
                case 2:
                    FruitTxtbox2.Image = fruits[val];
                    FruitTxtbox2.Refresh();
                    break;
                case 3:
                    FruitTxtbox3.Image = fruits[val];
                    FruitTxtbox3.Refresh();
                    break;
                default:
                    break;
            }
        }
        private void PicboxRefresh(int val1, int val2, int val3)
        {
            FruitTxtbox1.Image = fruits[val1];
            FruitTxtbox2.Image = fruits[val2];
            FruitTxtbox3.Image = fruits[val3];
            PicboxRefresh();
        }
        //assigns random images to picture boxes
        private void RandomRefresh()
        {
            Random r = new Random();
            PicboxRefresh(r.Next(NUM_OF_IMAGES), r.Next(NUM_OF_IMAGES), r.Next(NUM_OF_IMAGES));
        }

        private bool Validate(string input, out int output)
        {
            if (int.TryParse(input, out int temp))
            {
                if (temp == 0) { MessageTxtbox.Text = "YOU GOTTA BET SOMETHING!"; }
                else if (temp < 0) { MessageTxtbox.Text = "NICE TRY, PAL"; }
                else if (temp > 1000000) { MessageTxtbox.Text = "YOU WISH YOU HAD THAT MUCH"; }
                else
                {
                    output = temp;
                    return true;
                }
            }
            output = 0;
            return false;
        }

    }
}

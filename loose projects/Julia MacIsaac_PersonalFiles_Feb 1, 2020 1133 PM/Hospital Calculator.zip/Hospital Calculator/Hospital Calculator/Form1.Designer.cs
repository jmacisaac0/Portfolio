﻿namespace Hospital_Calculator
{
    partial class HospitalCalcForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DaysSpentTxtbox = new System.Windows.Forms.TextBox();
            this.MedChargeTxtbox = new System.Windows.Forms.TextBox();
            this.SurgicalChargeTxtbox = new System.Windows.Forms.TextBox();
            this.LabFeeTxtbox = new System.Windows.Forms.TextBox();
            this.RehabChargeTxtbox = new System.Windows.Forms.TextBox();
            this.StayChargeTxtbox = new System.Windows.Forms.TextBox();
            this.TotalTxtbox = new System.Windows.Forms.TextBox();
            this.MiscFeeTxtbox = new System.Windows.Forms.TextBox();
            this.FeeInputGrpbox = new System.Windows.Forms.GroupBox();
            this.RehabLbl = new System.Windows.Forms.Label();
            this.LabFeeLbl = new System.Windows.Forms.Label();
            this.SurgeryLbl = new System.Windows.Forms.Label();
            this.MedLbl = new System.Windows.Forms.Label();
            this.DaysSpentLbl = new System.Windows.Forms.Label();
            this.TotalGrpbox = new System.Windows.Forms.GroupBox();
            this.BillLbl = new System.Windows.Forms.Label();
            this.MiscLbl = new System.Windows.Forms.Label();
            this.HospitalStayLbl = new System.Windows.Forms.Label();
            this.DollarSignLbl1 = new System.Windows.Forms.Label();
            this.DollarSignLbl2 = new System.Windows.Forms.Label();
            this.DollarSignLbl3 = new System.Windows.Forms.Label();
            this.DollaSignLbl4 = new System.Windows.Forms.Label();
            this.FeeInputGrpbox.SuspendLayout();
            this.TotalGrpbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // DaysSpentTxtbox
            // 
            this.DaysSpentTxtbox.Location = new System.Drawing.Point(198, 19);
            this.DaysSpentTxtbox.Name = "DaysSpentTxtbox";
            this.DaysSpentTxtbox.Size = new System.Drawing.Size(155, 20);
            this.DaysSpentTxtbox.TabIndex = 0;
            this.DaysSpentTxtbox.TextChanged += new System.EventHandler(this.DaysSpentTxtbox_TextChanged);
            // 
            // MedChargeTxtbox
            // 
            this.MedChargeTxtbox.Location = new System.Drawing.Point(198, 45);
            this.MedChargeTxtbox.Name = "MedChargeTxtbox";
            this.MedChargeTxtbox.Size = new System.Drawing.Size(155, 20);
            this.MedChargeTxtbox.TabIndex = 2;
            this.MedChargeTxtbox.TextChanged += new System.EventHandler(this.MedChargeTxtbox_TextChanged);
            // 
            // SurgicalChargeTxtbox
            // 
            this.SurgicalChargeTxtbox.Location = new System.Drawing.Point(198, 71);
            this.SurgicalChargeTxtbox.Name = "SurgicalChargeTxtbox";
            this.SurgicalChargeTxtbox.Size = new System.Drawing.Size(155, 20);
            this.SurgicalChargeTxtbox.TabIndex = 3;
            this.SurgicalChargeTxtbox.TextChanged += new System.EventHandler(this.SurgicalChargeTxtbox_TextChanged);
            // 
            // LabFeeTxtbox
            // 
            this.LabFeeTxtbox.Location = new System.Drawing.Point(198, 97);
            this.LabFeeTxtbox.Name = "LabFeeTxtbox";
            this.LabFeeTxtbox.Size = new System.Drawing.Size(155, 20);
            this.LabFeeTxtbox.TabIndex = 4;
            this.LabFeeTxtbox.TextChanged += new System.EventHandler(this.LabFeeTxtbox_TextChanged);
            // 
            // RehabChargeTxtbox
            // 
            this.RehabChargeTxtbox.Location = new System.Drawing.Point(198, 123);
            this.RehabChargeTxtbox.Name = "RehabChargeTxtbox";
            this.RehabChargeTxtbox.Size = new System.Drawing.Size(155, 20);
            this.RehabChargeTxtbox.TabIndex = 5;
            this.RehabChargeTxtbox.TextChanged += new System.EventHandler(this.RehabChargeTxtbox_TextChanged);
            // 
            // StayChargeTxtbox
            // 
            this.StayChargeTxtbox.Location = new System.Drawing.Point(182, 19);
            this.StayChargeTxtbox.Name = "StayChargeTxtbox";
            this.StayChargeTxtbox.ReadOnly = true;
            this.StayChargeTxtbox.Size = new System.Drawing.Size(173, 20);
            this.StayChargeTxtbox.TabIndex = 6;
            this.StayChargeTxtbox.Text = "$    0";
            // 
            // TotalTxtbox
            // 
            this.TotalTxtbox.Location = new System.Drawing.Point(182, 71);
            this.TotalTxtbox.Name = "TotalTxtbox";
            this.TotalTxtbox.ReadOnly = true;
            this.TotalTxtbox.Size = new System.Drawing.Size(173, 20);
            this.TotalTxtbox.TabIndex = 7;
            this.TotalTxtbox.Text = "$    0";
            // 
            // MiscFeeTxtbox
            // 
            this.MiscFeeTxtbox.Location = new System.Drawing.Point(182, 45);
            this.MiscFeeTxtbox.Name = "MiscFeeTxtbox";
            this.MiscFeeTxtbox.ReadOnly = true;
            this.MiscFeeTxtbox.Size = new System.Drawing.Size(173, 20);
            this.MiscFeeTxtbox.TabIndex = 8;
            this.MiscFeeTxtbox.Text = "$    0";
            // 
            // FeeInputGrpbox
            // 
            this.FeeInputGrpbox.Controls.Add(this.DollaSignLbl4);
            this.FeeInputGrpbox.Controls.Add(this.DollarSignLbl3);
            this.FeeInputGrpbox.Controls.Add(this.DollarSignLbl2);
            this.FeeInputGrpbox.Controls.Add(this.DollarSignLbl1);
            this.FeeInputGrpbox.Controls.Add(this.LabFeeTxtbox);
            this.FeeInputGrpbox.Controls.Add(this.RehabLbl);
            this.FeeInputGrpbox.Controls.Add(this.DaysSpentTxtbox);
            this.FeeInputGrpbox.Controls.Add(this.LabFeeLbl);
            this.FeeInputGrpbox.Controls.Add(this.RehabChargeTxtbox);
            this.FeeInputGrpbox.Controls.Add(this.SurgeryLbl);
            this.FeeInputGrpbox.Controls.Add(this.MedChargeTxtbox);
            this.FeeInputGrpbox.Controls.Add(this.MedLbl);
            this.FeeInputGrpbox.Controls.Add(this.SurgicalChargeTxtbox);
            this.FeeInputGrpbox.Controls.Add(this.DaysSpentLbl);
            this.FeeInputGrpbox.Location = new System.Drawing.Point(12, 10);
            this.FeeInputGrpbox.Name = "FeeInputGrpbox";
            this.FeeInputGrpbox.Size = new System.Drawing.Size(361, 152);
            this.FeeInputGrpbox.TabIndex = 9;
            this.FeeInputGrpbox.TabStop = false;
            this.FeeInputGrpbox.Text = "Hospital Charges";
            // 
            // RehabLbl
            // 
            this.RehabLbl.AutoSize = true;
            this.RehabLbl.Location = new System.Drawing.Point(6, 126);
            this.RehabLbl.Name = "RehabLbl";
            this.RehabLbl.Size = new System.Drawing.Size(113, 13);
            this.RehabLbl.TabIndex = 13;
            this.RehabLbl.Text = "Physical Rehabilitation";
            // 
            // LabFeeLbl
            // 
            this.LabFeeLbl.AutoSize = true;
            this.LabFeeLbl.Location = new System.Drawing.Point(6, 100);
            this.LabFeeLbl.Name = "LabFeeLbl";
            this.LabFeeLbl.Size = new System.Drawing.Size(51, 13);
            this.LabFeeLbl.TabIndex = 12;
            this.LabFeeLbl.Text = "Lab Fees";
            // 
            // SurgeryLbl
            // 
            this.SurgeryLbl.AutoSize = true;
            this.SurgeryLbl.Location = new System.Drawing.Point(6, 74);
            this.SurgeryLbl.Name = "SurgeryLbl";
            this.SurgeryLbl.Size = new System.Drawing.Size(43, 13);
            this.SurgeryLbl.TabIndex = 11;
            this.SurgeryLbl.Text = "Surgery";
            // 
            // MedLbl
            // 
            this.MedLbl.AutoSize = true;
            this.MedLbl.Location = new System.Drawing.Point(6, 48);
            this.MedLbl.Name = "MedLbl";
            this.MedLbl.Size = new System.Drawing.Size(59, 13);
            this.MedLbl.TabIndex = 10;
            this.MedLbl.Text = "Medication";
            // 
            // DaysSpentLbl
            // 
            this.DaysSpentLbl.AutoSize = true;
            this.DaysSpentLbl.Location = new System.Drawing.Point(6, 22);
            this.DaysSpentLbl.Name = "DaysSpentLbl";
            this.DaysSpentLbl.Size = new System.Drawing.Size(114, 13);
            this.DaysSpentLbl.TabIndex = 6;
            this.DaysSpentLbl.Text = "Days Spent in Hospital";
            // 
            // TotalGrpbox
            // 
            this.TotalGrpbox.Controls.Add(this.BillLbl);
            this.TotalGrpbox.Controls.Add(this.MiscLbl);
            this.TotalGrpbox.Controls.Add(this.HospitalStayLbl);
            this.TotalGrpbox.Controls.Add(this.StayChargeTxtbox);
            this.TotalGrpbox.Controls.Add(this.MiscFeeTxtbox);
            this.TotalGrpbox.Controls.Add(this.TotalTxtbox);
            this.TotalGrpbox.Location = new System.Drawing.Point(12, 168);
            this.TotalGrpbox.Name = "TotalGrpbox";
            this.TotalGrpbox.Size = new System.Drawing.Size(361, 100);
            this.TotalGrpbox.TabIndex = 0;
            this.TotalGrpbox.TabStop = false;
            this.TotalGrpbox.Text = "Total Costs";
            // 
            // BillLbl
            // 
            this.BillLbl.AutoSize = true;
            this.BillLbl.Location = new System.Drawing.Point(6, 74);
            this.BillLbl.Name = "BillLbl";
            this.BillLbl.Size = new System.Drawing.Size(47, 13);
            this.BillLbl.TabIndex = 15;
            this.BillLbl.Text = "Total Bill";
            // 
            // MiscLbl
            // 
            this.MiscLbl.AutoSize = true;
            this.MiscLbl.Location = new System.Drawing.Point(6, 48);
            this.MiscLbl.Name = "MiscLbl";
            this.MiscLbl.Size = new System.Drawing.Size(100, 13);
            this.MiscLbl.TabIndex = 16;
            this.MiscLbl.Text = "Miscellaneous Fees";
            // 
            // HospitalStayLbl
            // 
            this.HospitalStayLbl.AutoSize = true;
            this.HospitalStayLbl.Location = new System.Drawing.Point(6, 22);
            this.HospitalStayLbl.Name = "HospitalStayLbl";
            this.HospitalStayLbl.Size = new System.Drawing.Size(69, 13);
            this.HospitalStayLbl.TabIndex = 14;
            this.HospitalStayLbl.Text = "Hospital Stay";
            // 
            // DollarSignLbl1
            // 
            this.DollarSignLbl1.AutoSize = true;
            this.DollarSignLbl1.Location = new System.Drawing.Point(179, 48);
            this.DollarSignLbl1.Name = "DollarSignLbl1";
            this.DollarSignLbl1.Size = new System.Drawing.Size(13, 13);
            this.DollarSignLbl1.TabIndex = 14;
            this.DollarSignLbl1.Text = "$";
            // 
            // DollarSignLbl2
            // 
            this.DollarSignLbl2.AutoSize = true;
            this.DollarSignLbl2.Location = new System.Drawing.Point(179, 74);
            this.DollarSignLbl2.Name = "DollarSignLbl2";
            this.DollarSignLbl2.Size = new System.Drawing.Size(13, 13);
            this.DollarSignLbl2.TabIndex = 15;
            this.DollarSignLbl2.Text = "$";
            // 
            // DollarSignLbl3
            // 
            this.DollarSignLbl3.AutoSize = true;
            this.DollarSignLbl3.Location = new System.Drawing.Point(179, 100);
            this.DollarSignLbl3.Name = "DollarSignLbl3";
            this.DollarSignLbl3.Size = new System.Drawing.Size(13, 13);
            this.DollarSignLbl3.TabIndex = 16;
            this.DollarSignLbl3.Text = "$";
            // 
            // DollaSignLbl4
            // 
            this.DollaSignLbl4.AutoSize = true;
            this.DollaSignLbl4.Location = new System.Drawing.Point(179, 126);
            this.DollaSignLbl4.Name = "DollaSignLbl4";
            this.DollaSignLbl4.Size = new System.Drawing.Size(13, 13);
            this.DollaSignLbl4.TabIndex = 17;
            this.DollaSignLbl4.Text = "$";
            // 
            // HospitalCalcForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 273);
            this.Controls.Add(this.TotalGrpbox);
            this.Controls.Add(this.FeeInputGrpbox);
            this.Name = "HospitalCalcForm";
            this.Text = "Hospital Fee Calculator";
            this.Load += new System.EventHandler(this.HospitalCalcForm_Load);
            this.FeeInputGrpbox.ResumeLayout(false);
            this.FeeInputGrpbox.PerformLayout();
            this.TotalGrpbox.ResumeLayout(false);
            this.TotalGrpbox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox DaysSpentTxtbox;
        private System.Windows.Forms.TextBox MedChargeTxtbox;
        private System.Windows.Forms.TextBox SurgicalChargeTxtbox;
        private System.Windows.Forms.TextBox LabFeeTxtbox;
        private System.Windows.Forms.TextBox RehabChargeTxtbox;
        private System.Windows.Forms.TextBox StayChargeTxtbox;
        private System.Windows.Forms.TextBox TotalTxtbox;
        private System.Windows.Forms.TextBox MiscFeeTxtbox;
        private System.Windows.Forms.GroupBox FeeInputGrpbox;
        private System.Windows.Forms.GroupBox TotalGrpbox;
        private System.Windows.Forms.Label DaysSpentLbl;
        private System.Windows.Forms.Label MedLbl;
        private System.Windows.Forms.Label SurgeryLbl;
        private System.Windows.Forms.Label LabFeeLbl;
        private System.Windows.Forms.Label RehabLbl;
        private System.Windows.Forms.Label HospitalStayLbl;
        private System.Windows.Forms.Label BillLbl;
        private System.Windows.Forms.Label MiscLbl;
        private System.Windows.Forms.Label DollaSignLbl4;
        private System.Windows.Forms.Label DollarSignLbl3;
        private System.Windows.Forms.Label DollarSignLbl2;
        private System.Windows.Forms.Label DollarSignLbl1;
    }
}


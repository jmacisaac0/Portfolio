﻿/*
 * Julian MacIsaac
 * Hospital Charges
 * M3 Hands-on Test
 */

using System;
using System.Windows.Forms;

namespace Hospital_Calculator
{
    public partial class HospitalCalcForm : Form
    {
        int stayCharge = 0;
        int miscCharge = 0;
        storeInt hospital = new storeInt();

        public HospitalCalcForm()
        {
            InitializeComponent();
        }

        private void HospitalCalcForm_Load(object sender, EventArgs e)
        {

        }

        private void DaysSpentTxtbox_TextChanged(object sender, EventArgs e)
        {
            //records value in textbox each time it changes. If the value isn't valid, the textbox is cleared
            if (!hospital.setDaysSpent(DaysSpentTxtbox.Text)) { DaysSpentTxtbox.Clear(); }
            CalcStayCharges();
        }

        private void MedChargeTxtbox_TextChanged(object sender, EventArgs e)
        {
            if (!hospital.setMedCharge(MedChargeTxtbox.Text)) { MedChargeTxtbox.Clear(); }
            CalcMiscCharges();
        }

        private void SurgicalChargeTxtbox_TextChanged(object sender, EventArgs e)
        {
            if (!hospital.setSurgeryCharge(SurgicalChargeTxtbox.Text)) { SurgicalChargeTxtbox.Clear(); }
            CalcMiscCharges();
        }

        private void LabFeeTxtbox_TextChanged(object sender, EventArgs e)
        {
            if (!hospital.setLabFee(LabFeeTxtbox.Text)) { LabFeeTxtbox.Clear(); }
            CalcMiscCharges();
        }

        private void RehabChargeTxtbox_TextChanged(object sender, EventArgs e)
        {
            if (!hospital.setRehabCharge(RehabChargeTxtbox.Text)) { RehabChargeTxtbox.Clear(); }
            CalcMiscCharges();
        }

        //methods
        private void CalcStayCharges()
        {
            //Calculates and returns the base charges for the hospital stay
            //This is computed as $350 times the number of days in the hospital
            stayCharge = hospital.getDaysSpent() * 350;
            StayChargeTxtbox.Text = ("$    " + stayCharge.ToString());
            CalcTotalCharges();
        }

        private void CalcMiscCharges()
        {
            //Calculates and returns the total of the 
            //medication, surgical, lab, and physical rehabilitation charges
            miscCharge = hospital.getLabFees() + hospital.getMedCharges() + 
                       hospital.getSurgeryCharges() + hospital.getRehabCharges();
            MiscFeeTxtbox.Text = ("$    " + miscCharge.ToString());
            CalcTotalCharges();
        }

        private void CalcTotalCharges()
        {
            //Calculates and returns the total charges
            TotalTxtbox.Text = ("$    " + (stayCharge + miscCharge).ToString());
        }

        private int Calculate()
        {
            return 0;
        }
        
        //Class is used for input validation and storage
        public class storeInt
        {
            private int daysSpent = 0;
            private int medCharges = 0;
            private int surgeryCharges = 0;
            private int labFees = 0;
            private int rehabCharges;

            //constructors
            public storeInt() { }

            //getters
            public int getDaysSpent()
            {
                return daysSpent;
            }
            public int getMedCharges()
            {
                return medCharges;
            }
            public int getSurgeryCharges()
            {
                return surgeryCharges;
            }
            public int getLabFees()
            {
                return labFees;
            }
            public int getRehabCharges()
            {
                return rehabCharges;
            }

            //setters
            public bool setDaysSpent(string input)
            {
                int temp = ConvertToInteger(input, out bool wasSet);
                //sets returned value only if the convertToInteger method successfully
                //validated the input string
                if (wasSet) { daysSpent = temp; }
                return wasSet;
            }
            public bool setMedCharge(string input)
            {
                int temp = ConvertToInteger(input, out bool wasSet);
                if (wasSet) { medCharges = temp; }
                return wasSet;
            }
            public bool setSurgeryCharge(string input)
            {
                int temp = ConvertToInteger(input, out bool wasSet);
                if (wasSet) { surgeryCharges = temp; }
                return wasSet;
            }
            public bool setLabFee(string input)
            {
                int temp = ConvertToInteger(input, out bool wasSet);
                if (wasSet) { labFees = temp; }
                return wasSet;
            }
            public bool setRehabCharge(string input)
            {
                int temp = ConvertToInteger(input, out bool wasSet);
                if (wasSet) { rehabCharges = temp; }
                return wasSet;
            }

            //class methods

            //converts and validates string input, then converts to integer
            private int ConvertToInteger(string input, out bool wasSet)
            {
                //wasSet is used to notify setters if conversion and validation were succesful
                int num;
                /* this condition is caught by the TryParse method used later, however I don't want
                 * a message box to appear when the input is blank. Because of code elswhere, this would cause
                 * messageboxes to appear twice each time ConvertToInteger fails
                 */
                if (input == "")
                {
                    wasSet = false;
                    return 0;
                }
                //checks if entered number is both a number and positive
                else if (!int.TryParse(input, out num) || !IsPositive(num))
                {
                    MessageBox.Show("Please enter a positive number");
                    wasSet = false;
                    return 0;
                }
                else
                {
                    wasSet = true;
                    return num;
                }
            }
            private bool IsPositive(int input)
            {
                if (input < 0)
                {
                    return false;
                }
                return true;
            }
        }

    }
}

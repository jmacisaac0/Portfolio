package bulletproof;
import java.util.Scanner;

/**
 * Julian MacIsaac
 * CPT-236-Assignment 2 - Bulletproof
 */
public class BulletProof {
    
    public static void main(String[] args) {
        //read in
        Scanner kbd = new Scanner(System.in);
        
        //get operands
        
        //get operator
        
        //run operation and print
    }
}